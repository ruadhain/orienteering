'Efficiently Solving the Orienteering Problem with the Cross Entropy Method' by Sean Rowan

Dependencies:
Matlab 2018, Mapping Toolbox (for visualisation of the real-world application)

There are 3 main code files to run for the three different classes of experiments.
Ensure that all folders and subfolders are added to the Matlab path, and navigate
to the "code > matlab" folder in the Matlab workspace. Note - this runs the C
implementation code by default.

1) Baseline velocity variation experiment
Run "code > main > main3.m"

2) Efficient recompute after 1 node change
Run "code > main > main_node_change.m"

3) Application to a real-world orienteering dataset
Run "code > main > main_realworld.m"

All cross entropy method code and its experiments/applications was written from scratch by Sean Rowan. It was initially written in Matlab, then reimplemented in C for a significant efficiency gain.

Baseline comparison experiments are based on the LKH algorithm described by
Ding, Huanyu, et al. ”A multi-resolution approach for discovery and 3-D modeling of archaeological sites using satellite imagery and a UAV-borne camera.” American Control Conference (ACC), 2016. IEEE, 2016.