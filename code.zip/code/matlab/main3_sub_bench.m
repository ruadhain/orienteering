function [tmpBenAvgReward, tmpBenAvgLeftBgt] = main3_sub_bench(experimentalData, BGTScala, curr_velocity, start_node)

rewardCounter = 0;
leftBgtAccumulator = 0;
totalDataNum = size(experimentalData, 3);
%totalDataNum = 1;
for datasetNo = 1:totalDataNum
    node = zeros(size(experimentalData,1), 2);
    node(:, 1:2)   = experimentalData(:, 1:2, datasetNo);
    rwd = experimentalData(:, 3, datasetNo)';
    
    [benReward, benTour] = benchmark_naive_algo(node, rwd, BGTScala, curr_velocity, start_node);
    rewardCounter = rewardCounter + benReward;
    leftBgtAccumulator = leftBgtAccumulator + (BGTScala - get_tour_cost(node, benTour, curr_velocity));
    disp(benTour);
    figure;
    plot_tour(benTour, node, rwd, BGTScala, 11, 'Benchmark', curr_velocity, start_node);
    
end

tmpBenAvgReward  = rewardCounter / totalDataNum;
tmpBenAvgLeftBgt = leftBgtAccumulator / totalDataNum;