function [ceReward, ceTour, trans_mat] = ce_algo_realworld(costs, rwd, BGT, start_node, init_trans_mat)

%Experimental parameters
c=1;           %Batch size
rho=0.3;       %Percentile cut-off for top performing paths
alpha=0.5;      %Update rate
epsilon = 0.000000000001;  %Stopping criterion 

normal_costs = costs;

%Normalise cost matrix
for i = 1:size(costs,1)
    costs(i,:) = costs(i,:)/sum(costs(i,:));
end

%Normalise rwd matrix
rwd_original = rwd;
rwd = rwd/sum(rwd);

%Transition matrix initialisation 
trans_mat = zeros(size(costs));
for i = 1:size(trans_mat,1)
    for j = 1:size(trans_mat,2)
        if (costs(i,j) ~= 0)
            if (rwd(j) == 0)
                trans_mat(i,j) = 0;
            elseif (rwd(j) == 1)
                rwd(j) = 0.99999999999999999999;  
            else
                trans_mat(i,j) = log(costs(i,j))/log(rwd(j));
            end
        end
    end
end

if (sum(sum(init_trans_mat)) ~= 0)
    c = 0.1;
    trans_mat = alpha*trans_mat + (1-alpha)*init_trans_mat;
end

%Remove diagonal elements from transition matrix and then renormalise
%(don't want to transition from same node twice)
trans_mat = trans_mat - diag(diag(trans_mat));

for i = 1:size(trans_mat,1)
    trans_mat(i,:) = trans_mat(i,:)/sum(trans_mat(i,:));
end

%Reserves space not only for a new matrix but
%also for a matrix from the previous iteration:  
trans_mat_old = trans_mat;

%Performance metrics    
gammas = [];
highest_scores = [];
P_maxmins = [];
diff_scores = [];
high_scored_paths = [];
while_cond = 1;

%While loop vars
n = length(costs);
N = c*n^2;
d = 5; 
t = 0;

while while_cond
    %rho is used to select the top percentile of best performing paths to
    %update the transition matrix probabilities with
    rho_quantile_idx = cast(rho*(N)+1,'uint8');
    
    path_list = zeros(N,n);
    
    %N is the number of paths to generate in this batch
    for i = 1:N
        
        %Initialise vars
        temp_trans_mat = trans_mat;
        path = zeros(1,n);
        %Origin node
        path(1) = start_node;
        %Node counter used to handle the case where budget runs out before
        %visiting all nodes
        p_i = 1;
        %Sum of total cost of transitions between nodes
        currentCost = 0;
        %First node choice is the origin
        choice = path(p_i);
        %n is the number of possible nodes to be visited once
        for k = 1:n-1
            %This ensures that this node isn't visited again (note that it doesn't
            %mean that it can't be passed over en route to another node)
            temp_trans_mat(:, choice) = 0;
            %Renormalise the transition matrix
            temp_trans_mat = bsxfun(@rdivide, temp_trans_mat, sum(temp_trans_mat,2));
            temp_trans_mat(isnan(temp_trans_mat)) = 0;
            
            %Randomly sample the node transition
            choice = randsample(n,1,true,temp_trans_mat(path(p_i), :)');
            %Cost of this transition
            connCost = normal_costs(path(p_i), choice);
            %Cost of returning the origin from this transition
            returnCost = normal_costs(choice, path(1));
            
            %Ensure that the budget isn't expended, if it isn't then
            %include this node in the path and update the running total
            %cost
            if (currentCost + connCost + returnCost <= BGT)
                p_i = p_i + 1;
                path(p_i) = choice;
                currentCost = currentCost + connCost; 
            end
            
        end
        %Ensures that the final node visited is the origin
        path(p_i) = path(1);
        %Add this path to the batch of paths
        path_list(i,:) = path;
        
    end
    
    %Calculate the path scores based on time travelled and reward at nodes
    scores = [];
    for i = 1:N
        cost_sum = 0;
        for k = 1:length(path_list(i,:))-1
            if (path_list(i,k+1) ~= 0)
                %The optimisation goal is to minimise this cost function ->
                %log(travel time between nodes) / log(reward at each node)
                if (rwd(path_list(i,k+1)) == 0)
                    continue;
                elseif (rwd(path_list(i,k+1)) == 1)
                    cost_sum = cost_sum + log(costs(path_list(i,k), path_list(i,k+1)))/log(0.99999999999999999999);  
                else
                    cost_sum = cost_sum + log(costs(path_list(i,k), path_list(i,k+1)))/log(rwd(path_list(i,k+1)));
                end
            end
        end
        scores = [scores; cost_sum];
    end
    %Sort the scores from lowest to highest (lower score is better)
    [B,I] = sort(scores,'descend');
    %Append the score to the path list for ease of reference
    scored_paths = zeros(N, n+1);
    for i = 1:N
        scored_paths(i,:) = [B(i), path_list(I(i),:)];
    end
    
    
    %Transition matrix update
    trans_mat_old = trans_mat;
    trans_mat = zeros(size(trans_mat));
    %Select the top performing percentile of nodes from the paths
    high_scored_paths = scored_paths(1:rho_quantile_idx+1,:);
    
    %Transition matrix counter
    for idy = 1:size(high_scored_paths,1)
        for idx = 2:size(high_scored_paths,2)-2
            i = high_scored_paths(idy,idx);
            j = high_scored_paths(idy,idx+1);
            %Account for node paths that don't visit all nodes due to
            %budget contraints
            if (i == 0 || j == 0)
                break
            else
                trans_mat(i,j) = trans_mat(i,j) + 1;
            end
        end
    end
    %Smoothly update the transition matrix
    trans_mat = bsxfun(@rdivide, trans_mat, sum(trans_mat,2));
    trans_mat(isnan(trans_mat)) = 0;
    
    trans_mat = alpha*trans_mat + (1-alpha)*trans_mat_old;
    
    trans_mat = bsxfun(@rdivide, trans_mat, sum(trans_mat,2));
    trans_mat(isnan(trans_mat)) = 0;
    
    
    %Optimisation performance metrics
    gammas = [gammas, scored_paths(rho_quantile_idx,1)];
    highest_scores = [highest_scores, scored_paths(1,1)];
    P_maxmins = [P_maxmins, min(max(trans_mat,[],2))];
    diff_scores = [diff_scores, length(unique(B))/N];
    
    %Check for stopping condition, if the same optimisation performance
    %(gamma) occurred d times in a row then stop.
    if t < d
        while_cond = 1;
    elseif (gammas(end) - gammas(end-1)) < epsilon && (gammas(end) >= gammas(end-1))
        while_cond = 0;
    end
    
    t = t + 1;
end

ceTour = high_scored_paths(1,2:end);
ceTour = ceTour(find(ceTour));
ceReward = sum(rwd_original(ceTour));









