/*
 * Student License - for use by students to meet course requirements and
 * perform academic research at degree granting institutions only.  Not
 * for government, commercial, or other organizational use.
 *
 * diag.c
 *
 * Code generation for function 'diag'
 *
 */

/* Include files */
#include <string.h>
#include "rt_nonfinite.h"
#include "ce_algo.h"
#include "diag.h"

/* Function Definitions */
void b_diag(const real_T v[100], real_T d[10000])
{
  int32_T j;
  memset(&d[0], 0, 10000U * sizeof(real_T));
  for (j = 0; j < 100; j++) {
    d[j + 100 * j] = v[j];
  }
}

void diag(const real_T v[10000], real_T d[100])
{
  int32_T k;
  for (k = 0; k < 100; k++) {
    d[k] = v[k + 100 * k];
  }
}

/* End of code generation (diag.c) */
