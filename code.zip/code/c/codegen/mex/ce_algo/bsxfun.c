/*
 * Student License - for use by students to meet course requirements and
 * perform academic research at degree granting institutions only.  Not
 * for government, commercial, or other organizational use.
 *
 * bsxfun.c
 *
 * Code generation for function 'bsxfun'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "ce_algo.h"
#include "bsxfun.h"

/* Function Definitions */
void bsxfun(const real_T a[10000], const real_T b[100], real_T c[10000])
{
  int32_T k;
  int32_T b_k;
  for (k = 0; k < 100; k++) {
    for (b_k = 0; b_k < 100; b_k++) {
      c[b_k + 100 * k] = a[b_k + 100 * k] / b[b_k];
    }
  }
}

/* End of code generation (bsxfun.c) */
