/*
 * Student License - for use by students to meet course requirements and
 * perform academic research at degree granting institutions only.  Not
 * for government, commercial, or other organizational use.
 *
 * ce_algo_realworld.h
 *
 * Code generation for function 'ce_algo_realworld'
 *
 */

#ifndef CE_ALGO_REALWORLD_H
#define CE_ALGO_REALWORLD_H

/* Include files */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "rtwtypes.h"
#include "ce_algo_realworld_types.h"

/* Function Declarations */
extern void ce_algo_realworld(const emlrtStack *sp, real_T costs[1156], real_T
  rwd[34], real_T BGT, real_T start_node, const real_T init_trans_mat[1156],
  real_T *ceReward, real_T ceTour_data[], int32_T ceTour_size[2], real_T
  trans_mat[1156]);

#endif

/* End of code generation (ce_algo_realworld.h) */
