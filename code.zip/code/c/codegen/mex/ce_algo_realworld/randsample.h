/*
 * Student License - for use by students to meet course requirements and
 * perform academic research at degree granting institutions only.  Not
 * for government, commercial, or other organizational use.
 *
 * randsample.h
 *
 * Code generation for function 'randsample'
 *
 */

#ifndef RANDSAMPLE_H
#define RANDSAMPLE_H

/* Include files */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "rtwtypes.h"
#include "ce_algo_realworld_types.h"

/* Function Declarations */
extern real_T randsample(const emlrtStack *sp, const real_T varargin_4[34]);

#endif

/* End of code generation (randsample.h) */
