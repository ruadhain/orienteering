/*
 * Student License - for use by students to meet course requirements and
 * perform academic research at degree granting institutions only.  Not
 * for government, commercial, or other organizational use.
 *
 * sum.h
 *
 * Code generation for function 'sum'
 *
 */

#ifndef SUM_H
#define SUM_H

/* Include files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "ce_algo_realworld_types.h"

/* Function Declarations */
extern void b_sum(const double x[1156], double y[34]);
extern void c_sum(const double x[1156], double y[34]);
extern double d_sum(const double x_data[], const int x_size[1]);
extern double sum(const double x[34]);

#endif

/* End of code generation (sum.h) */
