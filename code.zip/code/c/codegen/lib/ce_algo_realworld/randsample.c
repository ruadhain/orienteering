/*
 * Student License - for use by students to meet course requirements and
 * perform academic research at degree granting institutions only.  Not
 * for government, commercial, or other organizational use.
 *
 * randsample.c
 *
 * Code generation for function 'randsample'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "ce_algo_realworld.h"
#include "randsample.h"
#include "rand.h"

/* Function Definitions */
double randsample(const double varargin_4[34])
{
  double sumw;
  int low_i;
  double edges[35];
  double varargin_1;
  int low_ip1;
  int high_i;
  int mid_i;
  sumw = varargin_4[0];
  for (low_i = 0; low_i < 33; low_i++) {
    sumw += varargin_4[low_i + 1];
  }

  edges[0] = 0.0;
  edges[34] = 1.0;
  for (low_i = 0; low_i < 33; low_i++) {
    varargin_1 = edges[low_i] + varargin_4[low_i] / sumw;
    if (!(varargin_1 < 1.0)) {
      varargin_1 = 1.0;
    }

    edges[low_i + 1] = varargin_1;
  }

  sumw = b_rand();
  low_i = 0;
  if ((sumw >= edges[0]) && (sumw < edges[34])) {
    low_i = 1;
    low_ip1 = 2;
    high_i = 35;
    while (high_i > low_ip1) {
      mid_i = (low_i + high_i) >> 1;
      if (sumw >= edges[mid_i - 1]) {
        low_i = mid_i;
        low_ip1 = mid_i + 1;
      } else {
        high_i = mid_i;
      }
    }
  }

  if (sumw == edges[34]) {
    low_i = 35;
  }

  return low_i;
}

/* End of code generation (randsample.c) */
