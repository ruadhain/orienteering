/*
 * Student License - for use by students to meet course requirements and
 * perform academic research at degree granting institutions only.  Not
 * for government, commercial, or other organizational use.
 *
 * ce_algo_realworld.h
 *
 * Code generation for function 'ce_algo_realworld'
 *
 */

#ifndef CE_ALGO_REALWORLD_H
#define CE_ALGO_REALWORLD_H

/* Include files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "ce_algo_realworld_types.h"

/* Function Declarations */
extern void ce_algo_realworld(double costs[1156], double rwd[34], double BGT,
  double start_node, const double init_trans_mat[1156], double *ceReward, double
  ceTour_data[], int ceTour_size[2], double trans_mat[1156]);

#endif

/* End of code generation (ce_algo_realworld.h) */
