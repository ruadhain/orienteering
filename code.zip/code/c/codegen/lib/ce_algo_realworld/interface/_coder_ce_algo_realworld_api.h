/*
 * Student License - for use by students to meet course requirements and
 * perform academic research at degree granting institutions only.  Not
 * for government, commercial, or other organizational use.
 *
 * _coder_ce_algo_realworld_api.h
 *
 * Code generation for function '_coder_ce_algo_realworld_api'
 *
 */

#ifndef _CODER_CE_ALGO_REALWORLD_API_H
#define _CODER_CE_ALGO_REALWORLD_API_H

/* Include files */
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include <stddef.h>
#include <stdlib.h>
#include "_coder_ce_algo_realworld_api.h"

/* Variable Declarations */
extern emlrtCTX emlrtRootTLSGlobal;
extern emlrtContext emlrtContextGlobal;

/* Function Declarations */
extern void ce_algo_realworld(real_T costs[1156], real_T rwd[34], real_T BGT,
  real_T start_node, real_T init_trans_mat[1156], real_T *ceReward, real_T
  ceTour_data[], int32_T ceTour_size[2], real_T trans_mat[1156]);
extern void ce_algo_realworld_api(const mxArray * const prhs[5], int32_T nlhs,
  const mxArray *plhs[3]);
extern void ce_algo_realworld_atexit(void);
extern void ce_algo_realworld_initialize(void);
extern void ce_algo_realworld_terminate(void);
extern void ce_algo_realworld_xil_terminate(void);

#endif

/* End of code generation (_coder_ce_algo_realworld_api.h) */
