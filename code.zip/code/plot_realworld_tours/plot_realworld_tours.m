clear all; close all;

load('realworld_tours.txt');

load('CP.txt'); 
CP = CP(:,2:3);

tour = realworld_tours(1,:);
webmap;
wmcenter(CP(tour(1),1), CP(tour(1),2), 13);

for i = 1:length(tour)
   if (i == 1)
       wmmarker(CP(tour(i),1), CP(tour(i),2), 'FeatureName', string(i), 'Color', 'green')
   elseif (i == length(tour))
       lat = [CP(tour(i-1),1), CP(tour(i),1)];
       lon = [CP(tour(i-1),2), CP(tour(i),2)];
       wmline(lat, lon)
   else
       wmmarker(CP(tour(i),1), CP(tour(i),2), 'FeatureName', string(i), 'Color', 'red')
       lat = [CP(tour(i-1),1), CP(tour(i),1)];
       lon = [CP(tour(i-1),2), CP(tour(i),2)];
       wmline(lat, lon)
   end
end