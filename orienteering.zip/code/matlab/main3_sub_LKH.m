function [tmpLKHAvgReward, tmpLKHAvgLeftBgt] = main3_sub_LKH(experimentalData, BGTScala, curr_velocity, start_node)

rewardCounter = 0;
leftBgtAccumulator = 0;
totalDataNum = size(experimentalData, 3);

for datasetNo = 1:totalDataNum
    node = zeros(size(experimentalData,1), 2);
    node(:, 1:2)   = experimentalData(:, 1:2, datasetNo);
    rwd = experimentalData(:, 3, datasetNo)';
    
    [LKHReward, LKHTLKH] = greedy_algo(node, rwd, BGTScala, curr_velocity, start_node);
    rewardCounter = rewardCounter + LKHReward;
    leftBgtAccumulator = leftBgtAccumulator + (BGTScala - get_tour_cost(node, LKHTLKH, curr_velocity));
    
    figure;
    plot_tour(LKHTLKH, node, rwd, BGTScala, 11, 'LKH', curr_velocity, start_node);
    
end

tmpLKHAvgReward  = rewardCounter / totalDataNum;
tmpLKHAvgLeftBgt = leftBgtAccumulator / totalDataNum;
