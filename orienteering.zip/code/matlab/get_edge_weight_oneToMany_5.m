function result = get_edge_weight_oneToMany_5(nodeOne, nodeMultiple)
curr_velocity=2.0;
M = size(nodeMultiple,1);
result = zeros(M,1);
for ii = 1:M
    result(ii) = get_edge_weight(nodeOne, nodeMultiple(ii,:), curr_velocity);
end
