function [ceTour, ceReward, trans_mat] = main_realworld_sub_ce(costs, rwd, BGTScala, curr_velocity, start_node, init_trans_mats)

costs = costs/curr_velocity;

[ceReward, ceTour, trans_mat] = ce_algo_realworld_mex(costs, rwd, BGTScala, start_node, init_trans_mats(:,:,1));