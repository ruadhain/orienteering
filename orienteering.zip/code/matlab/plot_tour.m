function plot_tour(tour, node, rwd, BGT, figureBoundary, algName, curr_velocity, start_node) 
% Modified based on the original code by Jonas Lundgren <splinefit@gmail.com> 2012

% Plot TSP tour
x = node(tour,1);
x = [x;x(1)];
y = node(tour,2);
y = [y;y(1)];
plot(x,y,'r',x,y,'k.')
grid on; hold on

if nargin < 3
    figureBoundary = 100;
end
axis([0 figureBoundary 0 figureBoundary])

% Add title: total cost and reward of the tour
tourCost = 0;
for ii = 1:length(tour)
    if ii == length(tour)
        tourCost = tourCost + get_edge_weight(node(tour(ii),:), node(tour(1),:), curr_velocity);
    else
        tourCost = tourCost + get_edge_weight(node(tour(ii),:), node(tour(ii+1),:), curr_velocity);
    end
end
tourReward = sum(rwd(tour));

str = sprintf('Algorithm: %s; Reward: %g; Tour cost: %g; Budget: %g; Velocity: %g', algName, tourReward, tourCost, BGT, curr_velocity);
title(str);
xlabel('x-axis location') % x-axis label
ylabel('y-axis location') % y-axis label

% Plot all points
for k = 1:size(node, 1)
    if (k == start_node)
        plot(node(k,1), node(k,2), 'o', 'LineWidth', 2, 'Color',[0,1,0]);
    else
        str = sprintf(' (N:%d, T:%d,\n R:%.2f)', k, find(tour==k), rwd(k));
        text(node(k,1), node(k,2), str);
        plot(node(k,1), node(k,2), 'o', 'LineWidth', 2, 'Color',[rwd(k),0,0]);
    end
end