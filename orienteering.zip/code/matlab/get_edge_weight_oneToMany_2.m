function result = get_edge_weight_oneToMany_2(nodeOne, nodeMultiple)
curr_velocity=0.5;
M = size(nodeMultiple,1);
result = zeros(M,1);
for ii = 1:M
    result(ii) = get_edge_weight(nodeOne, nodeMultiple(ii,:), curr_velocity);
end
