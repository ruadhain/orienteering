function [tmpBenAvgReward, tmpBenAvgLeftBgt, trans_mats] = main3_sub_ce(experimentalData, BGTScala, curr_velocity, start_node, init_trans_mats)
trans_mats = [];
rewardCounter = 0;
leftBgtAccumulator = 0;
totalDataNum = size(experimentalData, 3);
%totalDataNum = 1;
for datasetNo = 1:totalDataNum
    node = zeros(size(experimentalData,1), 2);
    node(:, 1:2)   = experimentalData(:, 1:2, datasetNo);
    
    %Transition cost matrix
    costs = zeros(size(node,1), size(node,1));
    for i = 1:size(node,1)
        for j = 1:size(node,1)
            costs(i, j) = get_edge_weight(node(i,:), node(j,:), curr_velocity);
        end
    end
    
    rwd = experimentalData(:, 3, datasetNo)';
    [ceReward, ceTour, temp_trans_mat] = ce_algo_mex(costs, rwd, BGTScala, start_node, init_trans_mats(:,:,datasetNo));
    rewardCounter = rewardCounter + ceReward;
    leftBgtAccumulator = leftBgtAccumulator + (BGTScala - get_tour_cost(node, ceTour, curr_velocity));
    disp(rwd(1));
    trans_mats = [trans_mats; temp_trans_mat];
    figure;
    plot_tour(ceTour, node, rwd, BGTScala, 11, 'Cross Entropy', curr_velocity, start_node);
    
end

tmpBenAvgReward  = rewardCounter / totalDataNum;
tmpBenAvgLeftBgt = leftBgtAccumulator / totalDataNum;