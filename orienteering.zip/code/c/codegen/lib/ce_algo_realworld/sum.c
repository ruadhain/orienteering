/*
 * Student License - for use by students to meet course requirements and
 * perform academic research at degree granting institutions only.  Not
 * for government, commercial, or other organizational use.
 *
 * sum.c
 *
 * Code generation for function 'sum'
 *
 */

/* Include files */
#include <string.h>
#include "rt_nonfinite.h"
#include "ce_algo_realworld.h"
#include "sum.h"

/* Function Definitions */
void b_sum(const double x[1156], double y[34])
{
  int i;
  int xpageoffset;
  int k;
  for (i = 0; i < 34; i++) {
    xpageoffset = i * 34;
    y[i] = x[xpageoffset];
    for (k = 0; k < 33; k++) {
      y[i] += x[(xpageoffset + k) + 1];
    }
  }
}

void c_sum(const double x[1156], double y[34])
{
  int k;
  int xoffset;
  int j;
  memcpy(&y[0], &x[0], 34U * sizeof(double));
  for (k = 0; k < 33; k++) {
    xoffset = (k + 1) * 34;
    for (j = 0; j < 34; j++) {
      y[j] += x[xoffset + j];
    }
  }
}

double d_sum(const double x_data[], const int x_size[1])
{
  double y;
  int k;
  if (x_size[0] == 0) {
    y = 0.0;
  } else {
    y = x_data[0];
    for (k = 2; k <= x_size[0]; k++) {
      y += x_data[k - 1];
    }
  }

  return y;
}

double sum(const double x[34])
{
  double y;
  int k;
  y = x[0];
  for (k = 0; k < 33; k++) {
    y += x[k + 1];
  }

  return y;
}

/* End of code generation (sum.c) */
