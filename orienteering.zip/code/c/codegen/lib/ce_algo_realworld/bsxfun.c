/*
 * Student License - for use by students to meet course requirements and
 * perform academic research at degree granting institutions only.  Not
 * for government, commercial, or other organizational use.
 *
 * bsxfun.c
 *
 * Code generation for function 'bsxfun'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "ce_algo_realworld.h"
#include "bsxfun.h"

/* Function Definitions */
void bsxfun(const double a[1156], const double b[34], double c[1156])
{
  int k;
  int b_k;
  for (k = 0; k < 34; k++) {
    for (b_k = 0; b_k < 34; b_k++) {
      c[b_k + 34 * k] = a[b_k + 34 * k] / b[b_k];
    }
  }
}

/* End of code generation (bsxfun.c) */
