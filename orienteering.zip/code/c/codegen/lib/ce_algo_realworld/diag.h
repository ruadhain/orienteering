/*
 * Student License - for use by students to meet course requirements and
 * perform academic research at degree granting institutions only.  Not
 * for government, commercial, or other organizational use.
 *
 * diag.h
 *
 * Code generation for function 'diag'
 *
 */

#ifndef DIAG_H
#define DIAG_H

/* Include files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "ce_algo_realworld_types.h"

/* Function Declarations */
extern void b_diag(const double v[34], double d[1156]);
extern void diag(const double v[1156], double d[34]);

#endif

/* End of code generation (diag.h) */
