/*
 * Student License - for use by students to meet course requirements and
 * perform academic research at degree granting institutions only.  Not
 * for government, commercial, or other organizational use.
 *
 * ce_algo_realworld_data.c
 *
 * Code generation for function 'ce_algo_realworld_data'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "ce_algo_realworld.h"
#include "ce_algo_realworld_data.h"

/* Variable Definitions */
unsigned int state[625];

/* End of code generation (ce_algo_realworld_data.c) */
