/*
 * Student License - for use by students to meet course requirements and
 * perform academic research at degree granting institutions only.  Not
 * for government, commercial, or other organizational use.
 *
 * log.c
 *
 * Code generation for function 'log'
 *
 */

/* Include files */
#include <math.h>
#include "rt_nonfinite.h"
#include "ce_algo_realworld.h"
#include "log.h"

/* Function Definitions */
void b_log(double *x)
{
  *x = log(*x);
}

/* End of code generation (log.c) */
