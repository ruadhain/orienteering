/*
 * Student License - for use by students to meet course requirements and
 * perform academic research at degree granting institutions only.  Not
 * for government, commercial, or other organizational use.
 *
 * ce_algo_realworld.c
 *
 * Code generation for function 'ce_algo_realworld'
 *
 */

/* Include files */
#include <math.h>
#include <string.h>
#include "rt_nonfinite.h"
#include "ce_algo_realworld.h"
#include "randsample.h"
#include "bsxfun.h"
#include "sum.h"
#include "ce_algo_realworld_emxutil.h"
#include "log.h"
#include "sort1.h"
#include "diag.h"

/* Function Declarations */
static double rt_roundd_snf(double u);

/* Function Definitions */
static double rt_roundd_snf(double u)
{
  double y;
  if (fabs(u) < 4.503599627370496E+15) {
    if (u >= 0.5) {
      y = floor(u + 0.5);
    } else if (u > -0.5) {
      y = u * 0.0;
    } else {
      y = ceil(u - 0.5);
    }
  } else {
    y = u;
  }

  return y;
}

void ce_algo_realworld(double costs[1156], double rwd[34], double BGT, double
  start_node, const double init_trans_mat[1156], double *ceReward, double
  ceTour_data[], int ceTour_size[2], double trans_mat[1156])
{
  double c;
  double normal_costs[1156];
  int i;
  double absxk;
  int k;
  int i0;
  double rwd_original[34];
  double dv0[34];
  int khi;
  double b_trans_mat[34];
  double trans_mat_old[1156];
  double connCost;
  emxArray_real_T *gammas;
  int while_cond;
  double N;
  double t;
  emxArray_real_T *path_list;
  emxArray_real_T *scores;
  emxArray_real_T *scored_paths;
  emxArray_real_T *b;
  emxArray_int32_T *idx;
  emxArray_int32_T *iwork;
  unsigned char rho_quantile_idx;
  int high_scored_paths_size_idx_0;
  int loop_ub;
  int q;
  int p;
  double high_scored_paths_data[3115];
  int i2;
  double path[34];
  int rwd_original_size[1];
  int pEnd;
  double rwd_original_data[35];
  double b_connCost;
  double c_trans_mat[1156];
  boolean_T b0;
  boolean_T bv0[1156];
  short tmp_data[1156];
  short b_tmp_data[1156];
  short c_tmp_data[1156];
  int na;
  int n;
  unsigned int scores_idx_0;
  int qEnd;
  int kEnd;
  int exitg1;
  int exponent;

  /* Experimental parameters */
  c = 0.25;

  /* Batch size */
  /* Percentile cut-off for top performing paths */
  /* Update rate */
  /* Stopping criterion  */
  memcpy(&normal_costs[0], &costs[0], 1156U * sizeof(double));

  /* Normalise cost matrix */
  /* Normalise rwd matrix */
  for (i = 0; i < 34; i++) {
    absxk = costs[i];
    for (k = 0; k < 33; k++) {
      absxk += costs[i + 34 * (k + 1)];
    }

    for (i0 = 0; i0 < 34; i0++) {
      costs[i + 34 * i0] /= absxk;
    }

    rwd_original[i] = rwd[i];
  }

  absxk = rwd[0];
  for (k = 0; k < 33; k++) {
    absxk += rwd[k + 1];
  }

  for (i0 = 0; i0 < 34; i0++) {
    rwd[i0] /= absxk;
  }

  /* Transition matrix initialisation  */
  memset(&trans_mat[0], 0, 1156U * sizeof(double));
  for (i = 0; i < 34; i++) {
    for (khi = 0; khi < 34; khi++) {
      absxk = rwd[khi];
      if (costs[i + 34 * khi] != 0.0) {
        if (rwd[khi] == 0.0) {
          trans_mat[i + 34 * khi] = 0.0;
        } else if (rwd[khi] == 1.0) {
          absxk = 1.0;
        } else {
          connCost = rwd[khi];
          b_log(&connCost);
          trans_mat[i + 34 * khi] = log(costs[i + 34 * khi]) / connCost;
        }
      }

      rwd[khi] = absxk;
    }
  }

  b_sum(init_trans_mat, dv0);
  if (sum(dv0) != 0.0) {
    c = 0.1;
    for (i0 = 0; i0 < 1156; i0++) {
      trans_mat[i0] = 0.5 * trans_mat[i0] + 0.5 * init_trans_mat[i0];
    }
  }

  /* Remove diagonal elements from transition matrix and then renormalise */
  /* (don't want to transition from same node twice) */
  diag(trans_mat, b_trans_mat);
  b_diag(b_trans_mat, trans_mat_old);
  for (i0 = 0; i0 < 1156; i0++) {
    trans_mat[i0] -= trans_mat_old[i0];
  }

  for (i = 0; i < 34; i++) {
    for (i0 = 0; i0 < 34; i0++) {
      b_trans_mat[i0] = trans_mat[i + 34 * i0];
    }

    absxk = sum(b_trans_mat);
    for (i0 = 0; i0 < 34; i0++) {
      trans_mat[i + 34 * i0] /= absxk;
    }
  }

  emxInit_real_T(&gammas, 2);

  /* Reserves space not only for a new matrix but */
  /* also for a matrix from the previous iteration:   */
  /* Performance metrics     */
  i0 = gammas->size[0] * gammas->size[1];
  gammas->size[0] = 1;
  gammas->size[1] = 0;
  emxEnsureCapacity_real_T(gammas, i0);
  while_cond = 1;

  /* While loop vars */
  N = c * 1156.0;
  t = 0.0;
  emxInit_real_T(&path_list, 2);
  emxInit_real_T1(&scores, 1);
  emxInit_real_T(&scored_paths, 2);
  emxInit_real_T1(&b, 1);
  emxInit_int32_T(&idx, 1);
  emxInit_int32_T(&iwork, 1);
  i0 = (int)rt_roundd_snf(0.3 * N + 1.0);
  rho_quantile_idx = (unsigned char)i0;
  high_scored_paths_size_idx_0 = rho_quantile_idx + 1;
  loop_ub = rho_quantile_idx;
  i0 = rho_quantile_idx + 1;
  while (while_cond != 0) {
    /* rho is used to select the top percentile of best performing paths to */
    /* update the transition matrix probabilities with */
    /* N is the number of paths to generate in this batch */
    q = path_list->size[0] * path_list->size[1];
    path_list->size[0] = (int)N;
    path_list->size[1] = 34;
    emxEnsureCapacity_real_T(path_list, q);
    for (i = 0; i < (int)N; i++) {
      /* Initialise vars */
      memcpy(&trans_mat_old[0], &trans_mat[0], 1156U * sizeof(double));
      memset(&path[0], 0, 34U * sizeof(double));

      /* Origin node */
      path[0] = start_node;

      /* Node counter used to handle the case where budget runs out before */
      /* visiting all nodes */
      pEnd = 0;

      /* Sum of total cost of transitions between nodes */
      c = 0.0;

      /* First node choice is the origin */
      absxk = start_node;

      /* n is the number of possible nodes to be visited once */
      for (k = 0; k < 33; k++) {
        /* This ensures that this node isn't visited again (note that it doesn't */
        /* mean that it can't be passed over en route to another node) */
        memset(&trans_mat_old[(int)absxk * 34 + -34], 0, 34U * sizeof(double));

        /* Renormalise the transition matrix */
        c_sum(trans_mat_old, b_trans_mat);
        memcpy(&c_trans_mat[0], &trans_mat_old[0], 1156U * sizeof(double));
        bsxfun(c_trans_mat, b_trans_mat, trans_mat_old);
        p = 0;
        for (khi = 0; khi < 1156; khi++) {
          b0 = rtIsNaN(trans_mat_old[khi]);
          if (b0) {
            p++;
          }

          bv0[khi] = b0;
        }

        i2 = 0;
        for (khi = 0; khi < 1156; khi++) {
          if (bv0[khi]) {
            tmp_data[i2] = (short)(khi + 1);
            i2++;
          }
        }

        for (q = 0; q < p; q++) {
          trans_mat_old[tmp_data[q] - 1] = 0.0;
        }

        /* Randomly sample the node transition */
        for (q = 0; q < 34; q++) {
          b_trans_mat[q] = trans_mat_old[((int)path[pEnd] + 34 * q) - 1];
        }

        absxk = randsample(b_trans_mat);

        /* Cost of this transition */
        connCost = normal_costs[((int)path[pEnd] + 34 * ((int)absxk - 1)) - 1];

        /* Cost of returning the origin from this transition */
        /* Ensure that the budget isn't expended, if it isn't then */
        /* include this node in the path and update the running total */
        /* cost */
        if ((c + normal_costs[((int)path[pEnd] + 34 * ((int)absxk - 1)) - 1]) +
            normal_costs[((int)absxk + 34 * ((int)path[0] - 1)) - 1] <= BGT) {
          pEnd++;
          path[pEnd] = absxk;
          c += connCost;
        }
      }

      /* Ensures that the final node visited is the origin */
      path[pEnd] = path[0];

      /* Add this path to the batch of paths */
      for (q = 0; q < 34; q++) {
        path_list->data[i + path_list->size[0] * q] = path[q];
      }
    }

    /* Calculate the path scores based on time travelled and reward at nodes */
    q = scores->size[0];
    scores->size[0] = 0;
    emxEnsureCapacity_real_T1(scores, q);
    for (i = 0; i < (int)N; i++) {
      c = 0.0;
      for (k = 0; k < 33; k++) {
        if ((path_list->data[i + path_list->size[0] * (k + 1)] != 0.0) &&
            (!(rwd[(int)path_list->data[i + path_list->size[0] * (k + 1)] - 1] ==
               0.0))) {
          /* The optimisation goal is to minimise this cost function -> */
          /* log(travel time between nodes) / log(reward at each node) */
          if (rwd[(int)path_list->data[i + path_list->size[0] * (k + 1)] - 1] ==
              1.0) {
            connCost = costs[((int)path_list->data[i + path_list->size[0] * k] +
                              34 * ((int)path_list->data[i + path_list->size[0] *
              (k + 1)] - 1)) - 1];
            b_log(&connCost);
            if (connCost > 0.0) {
              b_connCost = rtInf;
            } else if (connCost < 0.0) {
              b_connCost = rtMinusInf;
            } else {
              b_connCost = rtNaN;
            }

            c += b_connCost;
          } else {
            connCost = costs[((int)path_list->data[i + path_list->size[0] * k] +
                              34 * ((int)path_list->data[i + path_list->size[0] *
              (k + 1)] - 1)) - 1];
            b_log(&connCost);
            absxk = rwd[(int)path_list->data[i + path_list->size[0] * (k + 1)] -
              1];
            b_log(&absxk);
            c += connCost / absxk;
          }
        }
      }

      khi = scores->size[0];
      q = scores->size[0];
      scores->size[0] = khi + 1;
      emxEnsureCapacity_real_T1(scores, q);
      scores->data[khi] = c;
    }

    /* Sort the scores from lowest to highest (lower score is better) */
    sort(scores, idx);
    q = b->size[0];
    b->size[0] = idx->size[0];
    emxEnsureCapacity_real_T1(b, q);
    khi = idx->size[0];
    for (q = 0; q < khi; q++) {
      b->data[q] = idx->data[q];
    }

    /* Append the score to the path list for ease of reference */
    q = scored_paths->size[0] * scored_paths->size[1];
    scored_paths->size[0] = (int)N;
    scored_paths->size[1] = 35;
    emxEnsureCapacity_real_T(scored_paths, q);
    for (i = 0; i < (int)N; i++) {
      i2 = (int)b->data[i];
      scored_paths->data[i] = scores->data[i];
      for (q = 0; q < 34; q++) {
        scored_paths->data[i + scored_paths->size[0] * (q + 1)] =
          path_list->data[(i2 + path_list->size[0] * q) - 1];
      }
    }

    /* Transition matrix update */
    for (q = 0; q < 1156; q++) {
      trans_mat_old[q] = trans_mat[q];
      trans_mat[q] = 0.0;
    }

    /* Select the top performing percentile of nodes from the paths */
    for (q = 0; q < 35; q++) {
      for (khi = 0; khi <= loop_ub; khi++) {
        high_scored_paths_data[khi + high_scored_paths_size_idx_0 * q] =
          scored_paths->data[khi + scored_paths->size[0] * q];
      }
    }

    /* Transition matrix counter */
    for (khi = 0; khi < i0; khi++) {
      i2 = 2;
      while ((i2 - 2 <= 31) && (!(scored_paths->data[khi + scored_paths->size[0]
               * (i2 - 1)] == 0.0)) && (!(scored_paths->data[khi +
               scored_paths->size[0] * i2] == 0.0))) {
        /* Account for node paths that don't visit all nodes due to */
        /* budget contraints */
        trans_mat[((int)scored_paths->data[khi + scored_paths->size[0] * (i2 - 1)]
                   + 34 * ((int)scored_paths->data[khi + scored_paths->size[0] *
                           i2] - 1)) - 1]++;
        i2++;
      }
    }

    /* Smoothly update the transition matrix */
    c_sum(trans_mat, b_trans_mat);
    memcpy(&c_trans_mat[0], &trans_mat[0], 1156U * sizeof(double));
    bsxfun(c_trans_mat, b_trans_mat, trans_mat);
    p = 0;
    for (i = 0; i < 1156; i++) {
      b0 = rtIsNaN(trans_mat[i]);
      if (b0) {
        p++;
      }

      bv0[i] = b0;
    }

    i2 = 0;
    for (i = 0; i < 1156; i++) {
      if (bv0[i]) {
        b_tmp_data[i2] = (short)(i + 1);
        i2++;
      }
    }

    for (q = 0; q < p; q++) {
      trans_mat[b_tmp_data[q] - 1] = 0.0;
    }

    for (q = 0; q < 1156; q++) {
      trans_mat[q] = 0.5 * trans_mat[q] + 0.5 * trans_mat_old[q];
    }

    c_sum(trans_mat, b_trans_mat);
    memcpy(&c_trans_mat[0], &trans_mat[0], 1156U * sizeof(double));
    bsxfun(c_trans_mat, b_trans_mat, trans_mat);
    p = 0;
    for (i = 0; i < 1156; i++) {
      b0 = rtIsNaN(trans_mat[i]);
      if (b0) {
        p++;
      }

      bv0[i] = b0;
    }

    i2 = 0;
    for (i = 0; i < 1156; i++) {
      if (bv0[i]) {
        c_tmp_data[i2] = (short)(i + 1);
        i2++;
      }
    }

    for (q = 0; q < p; q++) {
      trans_mat[c_tmp_data[q] - 1] = 0.0;
    }

    /* Optimisation performance metrics */
    khi = gammas->size[1];
    q = gammas->size[0] * gammas->size[1];
    gammas->size[1] = khi + 1;
    emxEnsureCapacity_real_T(gammas, q);
    gammas->data[khi] = scored_paths->data[rho_quantile_idx - 1];
    na = scores->size[0];
    n = scores->size[0] + 1;
    i2 = scores->size[0];
    q = idx->size[0];
    idx->size[0] = i2;
    emxEnsureCapacity_int32_T(idx, q);
    for (q = 0; q < i2; q++) {
      idx->data[q] = 0;
    }

    if (scores->size[0] != 0) {
      q = iwork->size[0];
      iwork->size[0] = i2;
      emxEnsureCapacity_int32_T(iwork, q);
      for (k = 1; k <= n - 2; k += 2) {
        if ((scores->data[k - 1] <= scores->data[k]) || rtIsNaN(scores->data[k]))
        {
          idx->data[k - 1] = k;
          idx->data[k] = k + 1;
        } else {
          idx->data[k - 1] = k + 1;
          idx->data[k] = k;
        }
      }

      if ((scores->size[0] & 1) != 0) {
        idx->data[scores->size[0] - 1] = scores->size[0];
      }

      i = 2;
      while (i < n - 1) {
        i2 = i << 1;
        khi = 1;
        for (pEnd = 1 + i; pEnd < n; pEnd = qEnd + i) {
          p = khi;
          q = pEnd - 1;
          qEnd = khi + i2;
          if (qEnd > n) {
            qEnd = n;
          }

          k = 0;
          kEnd = qEnd - khi;
          while (k + 1 <= kEnd) {
            if ((scores->data[idx->data[p - 1] - 1] <= scores->data[idx->data[q]
                 - 1]) || rtIsNaN(scores->data[idx->data[q] - 1])) {
              iwork->data[k] = idx->data[p - 1];
              p++;
              if (p == pEnd) {
                while (q + 1 < qEnd) {
                  k++;
                  iwork->data[k] = idx->data[q];
                  q++;
                }
              }
            } else {
              iwork->data[k] = idx->data[q];
              q++;
              if (q + 1 == qEnd) {
                while (p < pEnd) {
                  k++;
                  iwork->data[k] = idx->data[p - 1];
                  p++;
                }
              }
            }

            k++;
          }

          for (k = 0; k < kEnd; k++) {
            idx->data[(khi + k) - 1] = iwork->data[k];
          }

          khi = qEnd;
        }

        i = i2;
      }
    }

    scores_idx_0 = (unsigned int)scores->size[0];
    q = b->size[0];
    b->size[0] = (int)scores_idx_0;
    emxEnsureCapacity_real_T1(b, q);
    for (k = 0; k < na; k++) {
      b->data[k] = scores->data[idx->data[k] - 1];
    }

    k = 0;
    while ((k + 1 <= na) && rtIsInf(b->data[k]) && (b->data[k] < 0.0)) {
      k++;
    }

    pEnd = k;
    k = scores->size[0];
    while ((k >= 1) && rtIsNaN(b->data[k - 1])) {
      k--;
    }

    while ((k >= 1) && rtIsInf(b->data[k - 1]) && (b->data[k - 1] > 0.0)) {
      k--;
    }

    i2 = -1;
    if (pEnd > 0) {
      i2 = 0;
    }

    khi = (pEnd + k) - pEnd;
    while (pEnd + 1 <= khi) {
      c = b->data[pEnd];
      do {
        exitg1 = 0;
        pEnd++;
        if (pEnd + 1 > khi) {
          exitg1 = 1;
        } else {
          absxk = fabs(c / 2.0);
          if ((!rtIsInf(absxk)) && (!rtIsNaN(absxk))) {
            if (absxk <= 2.2250738585072014E-308) {
              absxk = 4.94065645841247E-324;
            } else {
              frexp(absxk, &exponent);
              absxk = ldexp(1.0, exponent - 53);
            }
          } else {
            absxk = rtNaN;
          }

          if ((fabs(c - b->data[pEnd]) < absxk) || (rtIsInf(b->data[pEnd]) &&
               rtIsInf(c) && ((b->data[pEnd] > 0.0) == (c > 0.0)))) {
          } else {
            exitg1 = 1;
          }
        }
      } while (exitg1 == 0);

      i2++;
      b->data[i2] = c;
    }

    /* Check for stopping condition, if the same optimisation performance */
    /* (gamma) occurred d times in a row then stop. */
    if ((!(t < 5.0)) && (gammas->data[gammas->size[1] - 1] - gammas->data
                         [gammas->size[1] - 2] < 0.1) && (gammas->data
         [gammas->size[1] - 1] >= gammas->data[gammas->size[1] - 2])) {
      while_cond = 0;
    }

    t++;
  }

  emxFree_int32_T(&iwork);
  emxFree_int32_T(&idx);
  emxFree_real_T(&b);
  emxFree_real_T(&scored_paths);
  emxFree_real_T(&scores);
  emxFree_real_T(&path_list);
  emxFree_real_T(&gammas);
  for (q = 0; q < 34; q++) {
    ceTour_data[q] = high_scored_paths_data[high_scored_paths_size_idx_0 * (1 +
      q)];
  }

  p = 0;
  for (i = 0; i < 34; i++) {
    if (high_scored_paths_data[high_scored_paths_size_idx_0 * (1 + i)] != 0.0) {
      p++;
    }
  }

  i2 = 0;
  for (i = 0; i < 34; i++) {
    if (ceTour_data[i] != 0.0) {
      ceTour_data[i2] = ceTour_data[i];
      i2++;
    }
  }

  ceTour_size[0] = 1;
  ceTour_size[1] = p;
  rwd_original_size[0] = p;
  for (i0 = 0; i0 < p; i0++) {
    rwd_original_data[i0] = rwd_original[(int)ceTour_data[i0] - 1];
  }

  *ceReward = d_sum(rwd_original_data, rwd_original_size);
}

/* End of code generation (ce_algo_realworld.c) */
