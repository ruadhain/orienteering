/*
 * Student License - for use by students to meet course requirements and
 * perform academic research at degree granting institutions only.  Not
 * for government, commercial, or other organizational use.
 *
 * ce_algo_realworld_data.h
 *
 * Code generation for function 'ce_algo_realworld_data'
 *
 */

#ifndef CE_ALGO_REALWORLD_DATA_H
#define CE_ALGO_REALWORLD_DATA_H

/* Include files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "ce_algo_realworld_types.h"

/* Variable Declarations */
extern unsigned int state[625];

#endif

/* End of code generation (ce_algo_realworld_data.h) */
