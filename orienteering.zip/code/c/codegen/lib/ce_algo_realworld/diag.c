/*
 * Student License - for use by students to meet course requirements and
 * perform academic research at degree granting institutions only.  Not
 * for government, commercial, or other organizational use.
 *
 * diag.c
 *
 * Code generation for function 'diag'
 *
 */

/* Include files */
#include <string.h>
#include "rt_nonfinite.h"
#include "ce_algo_realworld.h"
#include "diag.h"

/* Function Definitions */
void b_diag(const double v[34], double d[1156])
{
  int j;
  memset(&d[0], 0, 1156U * sizeof(double));
  for (j = 0; j < 34; j++) {
    d[j + 34 * j] = v[j];
  }
}

void diag(const double v[1156], double d[34])
{
  int k;
  for (k = 0; k < 34; k++) {
    d[k] = v[k + 34 * k];
  }
}

/* End of code generation (diag.c) */
