/*
 * Student License - for use by students to meet course requirements and
 * perform academic research at degree granting institutions only.  Not
 * for government, commercial, or other organizational use.
 *
 * ce_algo_realworld_terminate.c
 *
 * Code generation for function 'ce_algo_realworld_terminate'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "ce_algo_realworld.h"
#include "ce_algo_realworld_terminate.h"

/* Function Definitions */
void ce_algo_realworld_terminate(void)
{
  /* (no terminate code required) */
}

/* End of code generation (ce_algo_realworld_terminate.c) */
