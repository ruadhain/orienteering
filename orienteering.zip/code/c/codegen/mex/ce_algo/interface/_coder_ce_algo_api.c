/*
 * Student License - for use by students to meet course requirements and
 * perform academic research at degree granting institutions only.  Not
 * for government, commercial, or other organizational use.
 *
 * _coder_ce_algo_api.c
 *
 * Code generation for function '_coder_ce_algo_api'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "ce_algo.h"
#include "_coder_ce_algo_api.h"
#include "ce_algo_data.h"

/* Function Declarations */
static real_T (*b_emlrt_marshallIn(const emlrtStack *sp, const mxArray *u, const
  emlrtMsgIdentifier *parentId))[10000];
static const mxArray *b_emlrt_marshallOut(const real_T u_data[], const int32_T
  u_size[2]);
static real_T (*c_emlrt_marshallIn(const emlrtStack *sp, const mxArray *rwd,
  const char_T *identifier))[100];
static const mxArray *c_emlrt_marshallOut(const real_T u[10000]);
static real_T (*d_emlrt_marshallIn(const emlrtStack *sp, const mxArray *u, const
  emlrtMsgIdentifier *parentId))[100];
static real_T e_emlrt_marshallIn(const emlrtStack *sp, const mxArray *BGT, const
  char_T *identifier);
static real_T (*emlrt_marshallIn(const emlrtStack *sp, const mxArray *costs,
  const char_T *identifier))[10000];
static const mxArray *emlrt_marshallOut(const real_T u);
static real_T f_emlrt_marshallIn(const emlrtStack *sp, const mxArray *u, const
  emlrtMsgIdentifier *parentId);
static real_T (*g_emlrt_marshallIn(const emlrtStack *sp, const mxArray *src,
  const emlrtMsgIdentifier *msgId))[10000];
static real_T (*h_emlrt_marshallIn(const emlrtStack *sp, const mxArray *src,
  const emlrtMsgIdentifier *msgId))[100];
static real_T i_emlrt_marshallIn(const emlrtStack *sp, const mxArray *src, const
  emlrtMsgIdentifier *msgId);

/* Function Definitions */
static real_T (*b_emlrt_marshallIn(const emlrtStack *sp, const mxArray *u, const
  emlrtMsgIdentifier *parentId))[10000]
{
  real_T (*y)[10000];
  y = g_emlrt_marshallIn(sp, emlrtAlias(u), parentId);
  emlrtDestroyArray(&u);
  return y;
}
  static const mxArray *b_emlrt_marshallOut(const real_T u_data[], const int32_T
  u_size[2])
{
  const mxArray *y;
  const mxArray *m1;
  static const int32_T iv0[2] = { 0, 0 };

  y = NULL;
  m1 = emlrtCreateNumericArray(2, iv0, mxDOUBLE_CLASS, mxREAL);
  emlrtMxSetData((mxArray *)m1, (void *)&u_data[0]);
  emlrtSetDimensions((mxArray *)m1, u_size, 2);
  emlrtAssign(&y, m1);
  return y;
}

static real_T (*c_emlrt_marshallIn(const emlrtStack *sp, const mxArray *rwd,
  const char_T *identifier))[100]
{
  real_T (*y)[100];
  emlrtMsgIdentifier thisId;
  thisId.fIdentifier = (const char *)identifier;
  thisId.fParent = NULL;
  thisId.bParentIsCell = false;
  y = d_emlrt_marshallIn(sp, emlrtAlias(rwd), &thisId);
  emlrtDestroyArray(&rwd);
  return y;
}
  static const mxArray *c_emlrt_marshallOut(const real_T u[10000])
{
  const mxArray *y;
  const mxArray *m2;
  static const int32_T iv1[2] = { 0, 0 };

  static const int32_T iv2[2] = { 100, 100 };

  y = NULL;
  m2 = emlrtCreateNumericArray(2, iv1, mxDOUBLE_CLASS, mxREAL);
  emlrtMxSetData((mxArray *)m2, (void *)&u[0]);
  emlrtSetDimensions((mxArray *)m2, iv2, 2);
  emlrtAssign(&y, m2);
  return y;
}

static real_T (*d_emlrt_marshallIn(const emlrtStack *sp, const mxArray *u, const
  emlrtMsgIdentifier *parentId))[100]
{
  real_T (*y)[100];
  y = h_emlrt_marshallIn(sp, emlrtAlias(u), parentId);
  emlrtDestroyArray(&u);
  return y;
}
  static real_T e_emlrt_marshallIn(const emlrtStack *sp, const mxArray *BGT,
  const char_T *identifier)
{
  real_T y;
  emlrtMsgIdentifier thisId;
  thisId.fIdentifier = (const char *)identifier;
  thisId.fParent = NULL;
  thisId.bParentIsCell = false;
  y = f_emlrt_marshallIn(sp, emlrtAlias(BGT), &thisId);
  emlrtDestroyArray(&BGT);
  return y;
}

static real_T (*emlrt_marshallIn(const emlrtStack *sp, const mxArray *costs,
  const char_T *identifier))[10000]
{
  real_T (*y)[10000];
  emlrtMsgIdentifier thisId;
  thisId.fIdentifier = (const char *)identifier;
  thisId.fParent = NULL;
  thisId.bParentIsCell = false;
  y = b_emlrt_marshallIn(sp, emlrtAlias(costs), &thisId);
  emlrtDestroyArray(&costs);
  return y;
}
  static const mxArray *emlrt_marshallOut(const real_T u)
{
  const mxArray *y;
  const mxArray *m0;
  y = NULL;
  m0 = emlrtCreateDoubleScalar(u);
  emlrtAssign(&y, m0);
  return y;
}

static real_T f_emlrt_marshallIn(const emlrtStack *sp, const mxArray *u, const
  emlrtMsgIdentifier *parentId)
{
  real_T y;
  y = i_emlrt_marshallIn(sp, emlrtAlias(u), parentId);
  emlrtDestroyArray(&u);
  return y;
}

static real_T (*g_emlrt_marshallIn(const emlrtStack *sp, const mxArray *src,
  const emlrtMsgIdentifier *msgId))[10000]
{
  real_T (*ret)[10000];
  static const int32_T dims[2] = { 100, 100 };

  emlrtCheckBuiltInR2012b(sp, msgId, src, "double", false, 2U, dims);
  ret = (real_T (*)[10000])emlrtMxGetData(src);
  emlrtDestroyArray(&src);
  return ret;
}
  static real_T (*h_emlrt_marshallIn(const emlrtStack *sp, const mxArray *src,
  const emlrtMsgIdentifier *msgId))[100]
{
  real_T (*ret)[100];
  static const int32_T dims[2] = { 1, 100 };

  emlrtCheckBuiltInR2012b(sp, msgId, src, "double", false, 2U, dims);
  ret = (real_T (*)[100])emlrtMxGetData(src);
  emlrtDestroyArray(&src);
  return ret;
}

static real_T i_emlrt_marshallIn(const emlrtStack *sp, const mxArray *src, const
  emlrtMsgIdentifier *msgId)
{
  real_T ret;
  static const int32_T dims = 0;
  emlrtCheckBuiltInR2012b(sp, msgId, src, "double", false, 0U, &dims);
  ret = *(real_T *)emlrtMxGetData(src);
  emlrtDestroyArray(&src);
  return ret;
}

void ce_algo_api(ce_algoStackData *SD, const mxArray * const prhs[5], int32_T
                 nlhs, const mxArray *plhs[3])
{
  real_T (*ceTour_data)[101];
  real_T (*trans_mat)[10000];
  const mxArray *prhs_copy_idx_0;
  const mxArray *prhs_copy_idx_1;
  real_T (*costs)[10000];
  real_T (*rwd)[100];
  real_T BGT;
  real_T start_node;
  real_T (*init_trans_mat)[10000];
  real_T ceReward;
  int32_T ceTour_size[2];
  emlrtStack st = { NULL,              /* site */
    NULL,                              /* tls */
    NULL                               /* prev */
  };

  st.tls = emlrtRootTLSGlobal;
  ceTour_data = (real_T (*)[101])mxMalloc(sizeof(real_T [101]));
  trans_mat = (real_T (*)[10000])mxMalloc(sizeof(real_T [10000]));
  prhs_copy_idx_0 = emlrtProtectR2012b(prhs[0], 0, false, -1);
  prhs_copy_idx_1 = emlrtProtectR2012b(prhs[1], 1, false, -1);

  /* Marshall function inputs */
  costs = emlrt_marshallIn(&st, emlrtAlias(prhs_copy_idx_0), "costs");
  rwd = c_emlrt_marshallIn(&st, emlrtAlias(prhs_copy_idx_1), "rwd");
  BGT = e_emlrt_marshallIn(&st, emlrtAliasP(prhs[2]), "BGT");
  start_node = e_emlrt_marshallIn(&st, emlrtAliasP(prhs[3]), "start_node");
  init_trans_mat = emlrt_marshallIn(&st, emlrtAlias(prhs[4]), "init_trans_mat");

  /* Invoke the target function */
  ce_algo(SD, &st, *costs, *rwd, BGT, start_node, *init_trans_mat, &ceReward,
          *ceTour_data, ceTour_size, *trans_mat);

  /* Marshall function outputs */
  plhs[0] = emlrt_marshallOut(ceReward);
  if (nlhs > 1) {
    plhs[1] = b_emlrt_marshallOut(*ceTour_data, ceTour_size);
  }

  if (nlhs > 2) {
    plhs[2] = c_emlrt_marshallOut(*trans_mat);
  }
}

/* End of code generation (_coder_ce_algo_api.c) */
