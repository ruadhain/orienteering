/*
 * Student License - for use by students to meet course requirements and
 * perform academic research at degree granting institutions only.  Not
 * for government, commercial, or other organizational use.
 *
 * log.c
 *
 * Code generation for function 'log'
 *
 */

/* Include files */
#include "mwmathutil.h"
#include "rt_nonfinite.h"
#include "ce_algo.h"
#include "log.h"
#include "error.h"

/* Variable Definitions */
static emlrtRSInfo j_emlrtRSI = { 13,  /* lineNo */
  "log",                               /* fcnName */
  "/Applications/MATLAB_R2018a.app/toolbox/eml/lib/matlab/elfun/log.m"/* pathName */
};

/* Function Definitions */
void b_log(const emlrtStack *sp, real_T *x)
{
  emlrtStack st;
  st.prev = sp;
  st.tls = sp->tls;
  if (*x < 0.0) {
    st.site = &j_emlrtRSI;
    error(&st);
  }

  *x = muDoubleScalarLog(*x);
}

/* End of code generation (log.c) */
