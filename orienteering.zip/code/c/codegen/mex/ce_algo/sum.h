/*
 * Student License - for use by students to meet course requirements and
 * perform academic research at degree granting institutions only.  Not
 * for government, commercial, or other organizational use.
 *
 * sum.h
 *
 * Code generation for function 'sum'
 *
 */

#ifndef SUM_H
#define SUM_H

/* Include files */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "rtwtypes.h"
#include "ce_algo_types.h"

/* Function Declarations */
extern void b_sum(const real_T x[10000], real_T y[100]);
extern void c_sum(const real_T x[10000], real_T y[100]);
extern real_T d_sum(const emlrtStack *sp, const real_T x_data[], const int32_T
                    x_size[2]);
extern real_T sum(const real_T x[100]);

#endif

/* End of code generation (sum.h) */
