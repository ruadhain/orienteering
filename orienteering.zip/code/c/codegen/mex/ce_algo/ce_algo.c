/*
 * Student License - for use by students to meet course requirements and
 * perform academic research at degree granting institutions only.  Not
 * for government, commercial, or other organizational use.
 *
 * ce_algo.c
 *
 * Code generation for function 'ce_algo'
 *
 */

/* Include files */
#include <math.h>
#include <string.h>
#include "mwmathutil.h"
#include "rt_nonfinite.h"
#include "ce_algo.h"
#include "ce_algo_emxutil.h"
#include "sum.h"
#include "log.h"
#include "randsample.h"
#include "bsxfun.h"
#include "eml_int_forloop_overflow_check.h"
#include "sort1.h"
#include "toLogicalCheck.h"
#include "diag.h"
#include "ce_algo_data.h"

/* Variable Definitions */
static emlrtRSInfo emlrtRSI = { 199,   /* lineNo */
  "ce_algo",                           /* fcnName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo.m"/* pathName */
};

static emlrtRSInfo b_emlrtRSI = { 184, /* lineNo */
  "ce_algo",                           /* fcnName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo.m"/* pathName */
};

static emlrtRSInfo c_emlrtRSI = { 142, /* lineNo */
  "ce_algo",                           /* fcnName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo.m"/* pathName */
};

static emlrtRSInfo d_emlrtRSI = { 135, /* lineNo */
  "ce_algo",                           /* fcnName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo.m"/* pathName */
};

static emlrtRSInfo e_emlrtRSI = { 133, /* lineNo */
  "ce_algo",                           /* fcnName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo.m"/* pathName */
};

static emlrtRSInfo f_emlrtRSI = { 99,  /* lineNo */
  "ce_algo",                           /* fcnName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo.m"/* pathName */
};

static emlrtRSInfo g_emlrtRSI = { 67,  /* lineNo */
  "ce_algo",                           /* fcnName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo.m"/* pathName */
};

static emlrtRSInfo h_emlrtRSI = { 63,  /* lineNo */
  "ce_algo",                           /* fcnName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo.m"/* pathName */
};

static emlrtRSInfo i_emlrtRSI = { 30,  /* lineNo */
  "ce_algo",                           /* fcnName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo.m"/* pathName */
};

static emlrtRSInfo k_emlrtRSI = { 40,  /* lineNo */
  "mpower",                            /* fcnName */
  "/Applications/MATLAB_R2018a.app/toolbox/eml/lib/matlab/ops/mpower.m"/* pathName */
};

static emlrtRSInfo l_emlrtRSI = { 49,  /* lineNo */
  "power",                             /* fcnName */
  "/Applications/MATLAB_R2018a.app/toolbox/eml/lib/matlab/ops/power.m"/* pathName */
};

static emlrtRSInfo o_emlrtRSI = { 23,  /* lineNo */
  "sort",                              /* fcnName */
  "/Applications/MATLAB_R2018a.app/toolbox/eml/lib/matlab/datafun/sort.m"/* pathName */
};

static emlrtRSInfo tb_emlrtRSI = { 44, /* lineNo */
  "unique",                            /* fcnName */
  "/Applications/MATLAB_R2018a.app/toolbox/eml/lib/matlab/ops/unique.m"/* pathName */
};

static emlrtRSInfo ub_emlrtRSI = { 152,/* lineNo */
  "unique",                            /* fcnName */
  "/Applications/MATLAB_R2018a.app/toolbox/eml/lib/matlab/ops/unique.m"/* pathName */
};

static emlrtRSInfo vb_emlrtRSI = { 154,/* lineNo */
  "unique",                            /* fcnName */
  "/Applications/MATLAB_R2018a.app/toolbox/eml/lib/matlab/ops/unique.m"/* pathName */
};

static emlrtRSInfo wb_emlrtRSI = { 163,/* lineNo */
  "unique",                            /* fcnName */
  "/Applications/MATLAB_R2018a.app/toolbox/eml/lib/matlab/ops/unique.m"/* pathName */
};

static emlrtRSInfo xb_emlrtRSI = { 181,/* lineNo */
  "unique",                            /* fcnName */
  "/Applications/MATLAB_R2018a.app/toolbox/eml/lib/matlab/ops/unique.m"/* pathName */
};

static emlrtRSInfo yb_emlrtRSI = { 188,/* lineNo */
  "unique",                            /* fcnName */
  "/Applications/MATLAB_R2018a.app/toolbox/eml/lib/matlab/ops/unique.m"/* pathName */
};

static emlrtRSInfo ac_emlrtRSI = { 201,/* lineNo */
  "unique",                            /* fcnName */
  "/Applications/MATLAB_R2018a.app/toolbox/eml/lib/matlab/ops/unique.m"/* pathName */
};

static emlrtRSInfo bc_emlrtRSI = { 212,/* lineNo */
  "unique",                            /* fcnName */
  "/Applications/MATLAB_R2018a.app/toolbox/eml/lib/matlab/ops/unique.m"/* pathName */
};

static emlrtRSInfo cc_emlrtRSI = { 220,/* lineNo */
  "unique",                            /* fcnName */
  "/Applications/MATLAB_R2018a.app/toolbox/eml/lib/matlab/ops/unique.m"/* pathName */
};

static emlrtRSInfo dc_emlrtRSI = { 226,/* lineNo */
  "unique",                            /* fcnName */
  "/Applications/MATLAB_R2018a.app/toolbox/eml/lib/matlab/ops/unique.m"/* pathName */
};

static emlrtRSInfo ec_emlrtRSI = { 145,/* lineNo */
  "sortIdx",                           /* fcnName */
  "/Applications/MATLAB_R2018a.app/toolbox/eml/eml/+coder/+internal/sortIdx.m"/* pathName */
};

static emlrtRSInfo fc_emlrtRSI = { 57, /* lineNo */
  "mergesort",                         /* fcnName */
  "/Applications/MATLAB_R2018a.app/toolbox/eml/eml/+coder/+internal/mergesort.m"/* pathName */
};

static emlrtRSInfo gc_emlrtRSI = { 112,/* lineNo */
  "mergesort",                         /* fcnName */
  "/Applications/MATLAB_R2018a.app/toolbox/eml/eml/+coder/+internal/mergesort.m"/* pathName */
};

static emlrtRSInfo hc_emlrtRSI = { 31, /* lineNo */
  "safeEq",                            /* fcnName */
  "/Applications/MATLAB_R2018a.app/toolbox/eml/eml/+coder/+internal/safeEq.m"/* pathName */
};

static emlrtRSInfo ic_emlrtRSI = { 18, /* lineNo */
  "indexShapeCheck",                   /* fcnName */
  "/Applications/MATLAB_R2018a.app/toolbox/eml/eml/+coder/+internal/indexShapeCheck.m"/* pathName */
};

static emlrtRTEInfo emlrtRTEI = { 54,  /* lineNo */
  1,                                   /* colNo */
  "ce_algo",                           /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo.m"/* pName */
};

static emlrtRTEInfo b_emlrtRTEI = { 58,/* lineNo */
  1,                                   /* colNo */
  "ce_algo",                           /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo.m"/* pName */
};

static emlrtRTEInfo c_emlrtRTEI = { 144,/* lineNo */
  20,                                  /* colNo */
  "ce_algo",                           /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo.m"/* pName */
};

static emlrtRTEInfo d_emlrtRTEI = { 123,/* lineNo */
  5,                                   /* colNo */
  "ce_algo",                           /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo.m"/* pName */
};

static emlrtRTEInfo e_emlrtRTEI = { 1, /* lineNo */
  42,                                  /* colNo */
  "ce_algo",                           /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo.m"/* pName */
};

static emlrtRTEInfo f_emlrtRTEI = { 24,/* lineNo */
  5,                                   /* colNo */
  "sort",                              /* fName */
  "/Applications/MATLAB_R2018a.app/toolbox/eml/lib/matlab/datafun/sort.m"/* pName */
};

static emlrtRTEInfo g_emlrtRTEI = { 154,/* lineNo */
  5,                                   /* colNo */
  "ce_algo",                           /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo.m"/* pName */
};

static emlrtRTEInfo h_emlrtRTEI = { 152,/* lineNo */
  1,                                   /* colNo */
  "unique",                            /* fName */
  "/Applications/MATLAB_R2018a.app/toolbox/eml/lib/matlab/ops/unique.m"/* pName */
};

static emlrtRTEInfo i_emlrtRTEI = { 145,/* lineNo */
  23,                                  /* colNo */
  "sortIdx",                           /* fName */
  "/Applications/MATLAB_R2018a.app/toolbox/eml/eml/+coder/+internal/sortIdx.m"/* pName */
};

static emlrtRTEInfo j_emlrtRTEI = { 44,/* lineNo */
  13,                                  /* colNo */
  "unique",                            /* fName */
  "/Applications/MATLAB_R2018a.app/toolbox/eml/lib/matlab/ops/unique.m"/* pName */
};

static emlrtRTEInfo k_emlrtRTEI = { 72,/* lineNo */
  5,                                   /* colNo */
  "ce_algo",                           /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo.m"/* pName */
};

static emlrtRTEInfo l_emlrtRTEI = { 144,/* lineNo */
  5,                                   /* colNo */
  "ce_algo",                           /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo.m"/* pName */
};

static emlrtRTEInfo m_emlrtRTEI = { 1, /* lineNo */
  11,                                  /* colNo */
  "unique",                            /* fName */
  "/Applications/MATLAB_R2018a.app/toolbox/eml/lib/matlab/ops/unique.m"/* pName */
};

static emlrtRTEInfo n_emlrtRTEI = { 52,/* lineNo */
  1,                                   /* colNo */
  "mergesort",                         /* fName */
  "/Applications/MATLAB_R2018a.app/toolbox/eml/eml/+coder/+internal/mergesort.m"/* pName */
};

static emlrtBCInfo emlrtBCI = { -1,    /* iFirst */
  -1,                                  /* iLast */
  197,                                 /* lineNo */
  32,                                  /* colNo */
  "high_scored_paths",                 /* aName */
  "ce_algo",                           /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo b_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  197,                                 /* lineNo */
  28,                                  /* colNo */
  "high_scored_paths",                 /* aName */
  "ce_algo",                           /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  146,                                 /* lineNo */
  22,                                  /* colNo */
  "scored_paths",                      /* aName */
  "ce_algo",                           /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo d_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  146,                                 /* lineNo */
  46,                                  /* colNo */
  "path_list",                         /* aName */
  "ce_algo",                           /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo e_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  126,                                 /* lineNo */
  36,                                  /* colNo */
  "path_list",                         /* aName */
  "ce_algo",                           /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo f_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  118,                                 /* lineNo */
  19,                                  /* colNo */
  "path_list",                         /* aName */
  "ce_algo",                           /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo g_emlrtBCI = { 1,   /* iFirst */
  100,                                 /* iLast */
  103,                                 /* lineNo */
  47,                                  /* colNo */
  "normal_costs",                      /* aName */
  "ce_algo",                           /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo.m",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo emlrtDCI = { 103,   /* lineNo */
  47,                                  /* colNo */
  "ce_algo",                           /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo.m",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo h_emlrtBCI = { 1,   /* iFirst */
  100,                                 /* iLast */
  99,                                  /* lineNo */
  57,                                  /* colNo */
  "temp_trans_mat",                    /* aName */
  "ce_algo",                           /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo.m",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo b_emlrtDCI = { 99,  /* lineNo */
  57,                                  /* colNo */
  "ce_algo",                           /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo.m",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo i_emlrtBCI = { 1,   /* iFirst */
  100,                                 /* iLast */
  93,                                  /* lineNo */
  31,                                  /* colNo */
  "temp_trans_mat",                    /* aName */
  "ce_algo",                           /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo.m",/* pName */
  3                                    /* checkKind */
};

static emlrtDCInfo c_emlrtDCI = { 93,  /* lineNo */
  31,                                  /* colNo */
  "ce_algo",                           /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo.m",/* pName */
  1                                    /* checkKind */
};

static emlrtDCInfo d_emlrtDCI = { 72,  /* lineNo */
  23,                                  /* colNo */
  "ce_algo",                           /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo.m",/* pName */
  1                                    /* checkKind */
};

static emlrtRTEInfo v_emlrtRTEI = { 219,/* lineNo */
  1,                                   /* colNo */
  "unique",                            /* fName */
  "/Applications/MATLAB_R2018a.app/toolbox/eml/lib/matlab/ops/unique.m"/* pName */
};

static emlrtRTEInfo w_emlrtRTEI = { 88,/* lineNo */
  9,                                   /* colNo */
  "indexShapeCheck",                   /* fName */
  "/Applications/MATLAB_R2018a.app/toolbox/eml/eml/+coder/+internal/indexShapeCheck.m"/* pName */
};

static emlrtBCInfo j_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  198,                                 /* lineNo */
  10,                                  /* colNo */
  "ceTour",                            /* aName */
  "ce_algo",                           /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo k_emlrtBCI = { 1,   /* iFirst */
  100,                                 /* iLast */
  199,                                 /* lineNo */
  29,                                  /* colNo */
  "rwd_original",                      /* aName */
  "ce_algo",                           /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo.m",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo e_emlrtDCI = { 199, /* lineNo */
  29,                                  /* colNo */
  "ce_algo",                           /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo.m",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo l_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  190,                                 /* lineNo */
  13,                                  /* colNo */
  "gammas",                            /* aName */
  "ce_algo",                           /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo m_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  190,                                 /* lineNo */
  27,                                  /* colNo */
  "gammas",                            /* aName */
  "ce_algo",                           /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo n_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  190,                                 /* lineNo */
  56,                                  /* colNo */
  "gammas",                            /* aName */
  "ce_algo",                           /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo o_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  190,                                 /* lineNo */
  71,                                  /* colNo */
  "gammas",                            /* aName */
  "ce_algo",                           /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo p_emlrtBCI = { 1,   /* iFirst */
  100,                                 /* iLast */
  166,                                 /* lineNo */
  34,                                  /* colNo */
  "trans_mat",                         /* aName */
  "ce_algo",                           /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo.m",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo f_emlrtDCI = { 166, /* lineNo */
  34,                                  /* colNo */
  "ce_algo",                           /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo.m",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo q_emlrtBCI = { 1,   /* iFirst */
  100,                                 /* iLast */
  166,                                 /* lineNo */
  17,                                  /* colNo */
  "trans_mat",                         /* aName */
  "ce_algo",                           /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo.m",/* pName */
  3                                    /* checkKind */
};

static emlrtDCInfo g_emlrtDCI = { 166, /* lineNo */
  17,                                  /* colNo */
  "ce_algo",                           /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo.m",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo r_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  146,                                 /* lineNo */
  46,                                  /* colNo */
  "I",                                 /* aName */
  "ce_algo",                           /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo s_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  146,                                 /* lineNo */
  30,                                  /* colNo */
  "B",                                 /* aName */
  "ce_algo",                           /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo t_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  127,                                 /* lineNo */
  17,                                  /* colNo */
  "path_list",                         /* aName */
  "ce_algo",                           /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo u_emlrtBCI = { 1,   /* iFirst */
  100,                                 /* iLast */
  130,                                 /* lineNo */
  21,                                  /* colNo */
  "rwd",                               /* aName */
  "ce_algo",                           /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo.m",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo h_emlrtDCI = { 130, /* lineNo */
  21,                                  /* colNo */
  "ce_algo",                           /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo.m",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo v_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  130,                                 /* lineNo */
  21,                                  /* colNo */
  "path_list",                         /* aName */
  "ce_algo",                           /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo w_emlrtBCI = { 1,   /* iFirst */
  100,                                 /* iLast */
  132,                                 /* lineNo */
  25,                                  /* colNo */
  "rwd",                               /* aName */
  "ce_algo",                           /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo.m",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo i_emlrtDCI = { 132, /* lineNo */
  25,                                  /* colNo */
  "ce_algo",                           /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo.m",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo x_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  132,                                 /* lineNo */
  25,                                  /* colNo */
  "path_list",                         /* aName */
  "ce_algo",                           /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo y_emlrtBCI = { 1,   /* iFirst */
  100,                                 /* iLast */
  135,                                 /* lineNo */
  47,                                  /* colNo */
  "costs",                             /* aName */
  "ce_algo",                           /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo.m",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo j_emlrtDCI = { 135, /* lineNo */
  47,                                  /* colNo */
  "ce_algo",                           /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo.m",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo ab_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  135,                                 /* lineNo */
  47,                                  /* colNo */
  "path_list",                         /* aName */
  "ce_algo",                           /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo bb_emlrtBCI = { 1,  /* iFirst */
  100,                                 /* iLast */
  135,                                 /* lineNo */
  92,                                  /* colNo */
  "rwd",                               /* aName */
  "ce_algo",                           /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo.m",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo k_emlrtDCI = { 135, /* lineNo */
  92,                                  /* colNo */
  "ce_algo",                           /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo.m",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo cb_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  135,                                 /* lineNo */
  92,                                  /* colNo */
  "path_list",                         /* aName */
  "ce_algo",                           /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo db_emlrtBCI = { 1,  /* iFirst */
  100,                                 /* iLast */
  133,                                 /* lineNo */
  47,                                  /* colNo */
  "costs",                             /* aName */
  "ce_algo",                           /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo.m",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo l_emlrtDCI = { 133, /* lineNo */
  47,                                  /* colNo */
  "ce_algo",                           /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo.m",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo eb_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  133,                                 /* lineNo */
  47,                                  /* colNo */
  "path_list",                         /* aName */
  "ce_algo",                           /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo fb_emlrtBCI = { 1,  /* iFirst */
  100,                                 /* iLast */
  101,                                 /* lineNo */
  24,                                  /* colNo */
  "normal_costs",                      /* aName */
  "ce_algo",                           /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo.m",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo m_emlrtDCI = { 101, /* lineNo */
  24,                                  /* colNo */
  "ce_algo",                           /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo.m",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo gb_emlrtBCI = { 1,  /* iFirst */
  100,                                 /* iLast */
  110,                                 /* lineNo */
  17,                                  /* colNo */
  "path",                              /* aName */
  "ce_algo",                           /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo.m",/* pName */
  3                                    /* checkKind */
};

/* Function Definitions */
void ce_algo(ce_algoStackData *SD, const emlrtStack *sp, real_T costs[10000],
             real_T rwd[100], real_T BGT, real_T start_node, const real_T
             init_trans_mat[10000], real_T *ceReward, real_T ceTour_data[],
             int32_T ceTour_size[2], real_T trans_mat[10000])
{
  real_T c;
  int32_T i;
  int32_T q;
  real_T choice;
  real_T trans_mat_old[100];
  real_T rwd_original[100];
  real_T dv0[100];
  int32_T j;
  real_T x;
  emxArray_real_T *gammas;
  emxArray_real_T *high_scored_paths;
  int32_T while_cond;
  real_T N;
  real_T t;
  emxArray_real_T *path_list;
  emxArray_real_T *scores;
  emxArray_real_T *scored_paths;
  emxArray_real_T *b;
  emxArray_int32_T *idx;
  emxArray_int32_T *iwork;
  int32_T exitg1;
  int32_T p;
  int32_T kEnd;
  real_T path[100];
  int32_T i2;
  real_T cost_sum;
  int32_T qEnd;
  int32_T k;
  int32_T pEnd;
  int32_T rwd_original_size[2];
  real_T rwd_original_data[101];
  real_T b_trans_mat[10000];
  boolean_T overflow;
  boolean_T bv0[10000];
  int16_T tmp_data[10000];
  int16_T b_tmp_data[10000];
  real_T b_x;
  int16_T c_tmp_data[10000];
  int32_T na;
  int32_T n;
  uint32_T scores_idx_0;
  int32_T exitg2;
  int32_T exponent;
  int32_T i0;
  emlrtStack st;
  emlrtStack b_st;
  emlrtStack c_st;
  emlrtStack d_st;
  emlrtStack e_st;
  emlrtStack f_st;
  st.prev = sp;
  st.tls = sp->tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  c_st.prev = &b_st;
  c_st.tls = b_st.tls;
  d_st.prev = &c_st;
  d_st.tls = c_st.tls;
  e_st.prev = &d_st;
  e_st.tls = d_st.tls;
  f_st.prev = &e_st;
  f_st.tls = e_st.tls;
  emlrtHeapReferenceStackEnterFcnR2012b(sp);

  /* Experimental parameters */
  c = 0.25;

  /* Batch size */
  /* Percentile cut-off for top performing paths */
  /* Update rate */
  /* Stopping criterion  */
  memcpy(&SD->f0.normal_costs[0], &costs[0], 10000U * sizeof(real_T));

  /* Normalise cost matrix */
  i = 0;
  while (i < 100) {
    for (q = 0; q < 100; q++) {
      trans_mat_old[q] = costs[i + 100 * q];
    }

    choice = sum(trans_mat_old);
    for (q = 0; q < 100; q++) {
      costs[i + 100 * q] /= choice;
    }

    i++;
    if (*emlrtBreakCheckR2012bFlagVar != 0) {
      emlrtBreakCheckR2012b(sp);
    }
  }

  /* Normalise rwd matrix */
  choice = sum(rwd);
  for (q = 0; q < 100; q++) {
    rwd_original[q] = rwd[q];
    rwd[q] /= choice;
  }

  /* Transition matrix initialisation  */
  memset(&trans_mat[0], 0, 10000U * sizeof(real_T));
  i = 0;
  while (i < 100) {
    j = 0;
    while (j < 100) {
      if (costs[i + 100 * j] != 0.0) {
        if (rwd[j] == 0.0) {
          trans_mat[i + 100 * j] = 0.0;
        } else if (rwd[j] == 1.0) {
          rwd[j] = 1.0;
        } else {
          x = costs[i + 100 * j];
          st.site = &i_emlrtRSI;
          b_log(&st, &x);
          choice = rwd[j];
          st.site = &i_emlrtRSI;
          b_log(&st, &choice);
          trans_mat[i + 100 * j] = x / choice;
        }
      }

      j++;
      if (*emlrtBreakCheckR2012bFlagVar != 0) {
        emlrtBreakCheckR2012b(sp);
      }
    }

    i++;
    if (*emlrtBreakCheckR2012bFlagVar != 0) {
      emlrtBreakCheckR2012b(sp);
    }
  }

  b_sum(init_trans_mat, dv0);
  if (sum(dv0) != 0.0) {
    c = 0.1;
    for (q = 0; q < 10000; q++) {
      trans_mat[q] = 0.5 * trans_mat[q] + 0.5 * init_trans_mat[q];
    }
  }

  /* Remove diagonal elements from transition matrix and then renormalise */
  /* (don't want to transition from same node twice) */
  diag(trans_mat, trans_mat_old);
  b_diag(trans_mat_old, SD->f0.trans_mat_old);
  for (q = 0; q < 10000; q++) {
    trans_mat[q] -= SD->f0.trans_mat_old[q];
  }

  i = 0;
  while (i < 100) {
    for (q = 0; q < 100; q++) {
      trans_mat_old[q] = trans_mat[i + 100 * q];
    }

    choice = sum(trans_mat_old);
    for (q = 0; q < 100; q++) {
      trans_mat[i + 100 * q] /= choice;
    }

    i++;
    if (*emlrtBreakCheckR2012bFlagVar != 0) {
      emlrtBreakCheckR2012b(sp);
    }
  }

  emxInit_real_T(sp, &gammas, 2, &emlrtRTEI, true);
  emxInit_real_T(sp, &high_scored_paths, 2, &b_emlrtRTEI, true);

  /* Reserves space not only for a new matrix but */
  /* also for a matrix from the previous iteration:   */
  /* Performance metrics     */
  q = gammas->size[0] * gammas->size[1];
  gammas->size[0] = 1;
  gammas->size[1] = 0;
  emxEnsureCapacity_real_T(sp, gammas, q, &emlrtRTEI);
  q = high_scored_paths->size[0] * high_scored_paths->size[1];
  high_scored_paths->size[0] = 0;
  high_scored_paths->size[1] = 0;
  emxEnsureCapacity_real_T(sp, high_scored_paths, q, &b_emlrtRTEI);
  while_cond = 1;

  /* While loop vars */
  st.site = &h_emlrtRSI;
  b_st.site = &k_emlrtRSI;
  c_st.site = &l_emlrtRSI;
  N = c * 10000.0;
  t = 0.0;
  emxInit_real_T(sp, &path_list, 2, &k_emlrtRTEI, true);
  emxInit_real_T1(sp, &scores, 1, &d_emlrtRTEI, true);
  emxInit_real_T(sp, &scored_paths, 2, &l_emlrtRTEI, true);
  emxInit_real_T1(sp, &b, 1, &m_emlrtRTEI, true);
  emxInit_int32_T(sp, &idx, 1, &h_emlrtRTEI, true);
  emxInit_int32_T(sp, &iwork, 1, &n_emlrtRTEI, true);
  do {
    exitg1 = 0;
    st.site = &g_emlrtRSI;
    toLogicalCheck(&st, while_cond);
    if (while_cond != 0) {
      /* rho is used to select the top percentile of best performing paths to */
      /* update the transition matrix probabilities with */
      if (N != muDoubleScalarFloor(N)) {
        emlrtIntegerCheckR2012b(N, &d_emlrtDCI, sp);
      }

      /* N is the number of paths to generate in this batch */
      q = path_list->size[0] * path_list->size[1];
      path_list->size[0] = (int32_T)N;
      path_list->size[1] = 100;
      emxEnsureCapacity_real_T(sp, path_list, q, &c_emlrtRTEI);
      i = 0;
      while (i <= (int32_T)N - 1) {
        /* Initialise vars */
        memcpy(&SD->f0.trans_mat_old[0], &trans_mat[0], 10000U * sizeof(real_T));
        memset(&path[0], 0, 100U * sizeof(real_T));

        /* Origin node */
        path[0] = start_node;

        /* Node counter used to handle the case where budget runs out before */
        /* visiting all nodes */
        qEnd = 0;

        /* Sum of total cost of transitions between nodes */
        c = 0.0;

        /* First node choice is the origin */
        choice = start_node;

        /* n is the number of possible nodes to be visited once */
        k = 0;
        while (k < 99) {
          /* This ensures that this node isn't visited again (note that it doesn't */
          /* mean that it can't be passed over en route to another node) */
          if (choice != (int32_T)muDoubleScalarFloor(choice)) {
            emlrtIntegerCheckR2012b(choice, &c_emlrtDCI, sp);
          }

          q = (int32_T)choice;
          if (!((q >= 1) && (q <= 100))) {
            emlrtDynamicBoundsCheckR2012b(q, 1, 100, &i_emlrtBCI, sp);
          }

          memset(&SD->f0.trans_mat_old[(int32_T)choice * 100 + -100], 0, 100U *
                 sizeof(real_T));

          /* Renormalise the transition matrix */
          c_sum(SD->f0.trans_mat_old, trans_mat_old);
          memcpy(&b_trans_mat[0], &SD->f0.trans_mat_old[0], 10000U * sizeof
                 (real_T));
          bsxfun(b_trans_mat, trans_mat_old, SD->f0.trans_mat_old);
          kEnd = 0;
          for (i2 = 0; i2 < 10000; i2++) {
            overflow = muDoubleScalarIsNaN(SD->f0.trans_mat_old[i2]);
            if (overflow) {
              kEnd++;
            }

            bv0[i2] = overflow;
          }

          pEnd = 0;
          for (i2 = 0; i2 < 10000; i2++) {
            if (bv0[i2]) {
              tmp_data[pEnd] = (int16_T)(i2 + 1);
              pEnd++;
            }
          }

          for (q = 0; q < kEnd; q++) {
            SD->f0.trans_mat_old[tmp_data[q] - 1] = 0.0;
          }

          /* Randomly sample the node transition */
          if (path[qEnd] != (int32_T)muDoubleScalarFloor(path[qEnd])) {
            emlrtIntegerCheckR2012b(path[qEnd], &b_emlrtDCI, sp);
          }

          q = (int32_T)path[qEnd];
          if (!((q >= 1) && (q <= 100))) {
            emlrtDynamicBoundsCheckR2012b(q, 1, 100, &h_emlrtBCI, sp);
          }

          for (q = 0; q < 100; q++) {
            trans_mat_old[q] = SD->f0.trans_mat_old[((int32_T)path[qEnd] + 100 *
              q) - 1];
          }

          st.site = &f_emlrtRSI;
          choice = randsample(&st, trans_mat_old);

          /* Cost of this transition */
          if (path[qEnd] != (int32_T)muDoubleScalarFloor(path[qEnd])) {
            emlrtIntegerCheckR2012b(path[qEnd], &m_emlrtDCI, sp);
          }

          q = (int32_T)path[qEnd];
          if (!((q >= 1) && (q <= 100))) {
            emlrtDynamicBoundsCheckR2012b(q, 1, 100, &fb_emlrtBCI, sp);
          }

          p = (int32_T)choice;
          if (!((p >= 1) && (p <= 100))) {
            emlrtDynamicBoundsCheckR2012b(p, 1, 100, &fb_emlrtBCI, sp);
          }

          cost_sum = SD->f0.normal_costs[(q + 100 * (p - 1)) - 1];

          /* Cost of returning the origin from this transition */
          if (path[0] != (int32_T)muDoubleScalarFloor(path[0])) {
            emlrtIntegerCheckR2012b(path[0], &emlrtDCI, sp);
          }

          q = (int32_T)path[0];
          if (!((q >= 1) && (q <= 100))) {
            emlrtDynamicBoundsCheckR2012b(q, 1, 100, &g_emlrtBCI, sp);
          }

          /* Ensure that the budget isn't expended, if it isn't then */
          /* include this node in the path and update the running total */
          /* cost */
          if ((c + SD->f0.normal_costs[((int32_T)path[qEnd] + 100 * ((int32_T)
                 choice - 1)) - 1]) + SD->f0.normal_costs[((int32_T)choice + 100
               * ((int32_T)path[0] - 1)) - 1] <= BGT) {
            qEnd++;
            if (!((qEnd + 1 >= 1) && (qEnd + 1 <= 100))) {
              emlrtDynamicBoundsCheckR2012b(qEnd + 1, 1, 100, &gb_emlrtBCI, sp);
            }

            path[qEnd] = choice;
            c += cost_sum;
          }

          k++;
          if (*emlrtBreakCheckR2012bFlagVar != 0) {
            emlrtBreakCheckR2012b(sp);
          }
        }

        /* Ensures that the final node visited is the origin */
        path[qEnd] = path[0];

        /* Add this path to the batch of paths */
        i2 = path_list->size[0];
        if (!(i + 1 <= i2)) {
          emlrtDynamicBoundsCheckR2012b(i + 1, 1, i2, &f_emlrtBCI, sp);
        }

        for (q = 0; q < 100; q++) {
          path_list->data[i + path_list->size[0] * q] = path[q];
        }

        i++;
        if (*emlrtBreakCheckR2012bFlagVar != 0) {
          emlrtBreakCheckR2012b(sp);
        }
      }

      /* Calculate the path scores based on time travelled and reward at nodes */
      q = scores->size[0];
      scores->size[0] = 0;
      emxEnsureCapacity_real_T1(sp, scores, q, &d_emlrtRTEI);
      i = 1;
      while (i - 1 <= (int32_T)N - 1) {
        cost_sum = 0.0;
        q = path_list->size[0];
        p = (i - 1) + 1;
        if (!((p >= 1) && (p <= q))) {
          emlrtDynamicBoundsCheckR2012b(p, 1, q, &e_emlrtBCI, sp);
        }

        k = 1;
        while (k - 1 < 99) {
          q = path_list->size[0];
          if (!((i >= 1) && (i <= q))) {
            emlrtDynamicBoundsCheckR2012b(i, 1, q, &t_emlrtBCI, sp);
          }

          if (path_list->data[(i + path_list->size[0] * k) - 1] != 0.0) {
            /* The optimisation goal is to minimise this cost function -> */
            /* log(travel time between nodes) / log(reward at each node) */
            q = path_list->size[0];
            if (!((i >= 1) && (i <= q))) {
              emlrtDynamicBoundsCheckR2012b(i, 1, q, &v_emlrtBCI, sp);
            }

            c = path_list->data[(i + path_list->size[0] * k) - 1];
            if (c != (int32_T)muDoubleScalarFloor(c)) {
              emlrtIntegerCheckR2012b(c, &h_emlrtDCI, sp);
            }

            q = (int32_T)c;
            if (!((q >= 1) && (q <= 100))) {
              emlrtDynamicBoundsCheckR2012b(q, 1, 100, &u_emlrtBCI, sp);
            }

            if (rwd[q - 1] == 0.0) {
            } else {
              q = path_list->size[0];
              if (!((i >= 1) && (i <= q))) {
                emlrtDynamicBoundsCheckR2012b(i, 1, q, &x_emlrtBCI, sp);
              }

              c = path_list->data[(i + path_list->size[0] * k) - 1];
              if (c != (int32_T)muDoubleScalarFloor(c)) {
                emlrtIntegerCheckR2012b(c, &i_emlrtDCI, sp);
              }

              q = (int32_T)c;
              if (!((q >= 1) && (q <= 100))) {
                emlrtDynamicBoundsCheckR2012b(q, 1, 100, &w_emlrtBCI, sp);
              }

              if (rwd[q - 1] == 1.0) {
                q = path_list->size[0];
                if (!((i >= 1) && (i <= q))) {
                  emlrtDynamicBoundsCheckR2012b(i, 1, q, &eb_emlrtBCI, sp);
                }

                c = path_list->data[(i + path_list->size[0] * (k - 1)) - 1];
                if (c != (int32_T)muDoubleScalarFloor(c)) {
                  emlrtIntegerCheckR2012b(c, &l_emlrtDCI, sp);
                }

                q = (int32_T)c;
                if (!((q >= 1) && (q <= 100))) {
                  emlrtDynamicBoundsCheckR2012b(q, 1, 100, &db_emlrtBCI, sp);
                }

                p = path_list->size[0];
                if (!((i >= 1) && (i <= p))) {
                  emlrtDynamicBoundsCheckR2012b(i, 1, p, &eb_emlrtBCI, sp);
                }

                c = path_list->data[(i + path_list->size[0] * k) - 1];
                if (c != (int32_T)muDoubleScalarFloor(c)) {
                  emlrtIntegerCheckR2012b(c, &l_emlrtDCI, sp);
                }

                p = (int32_T)c;
                if (!((p >= 1) && (p <= 100))) {
                  emlrtDynamicBoundsCheckR2012b(p, 1, 100, &db_emlrtBCI, sp);
                }

                x = costs[(q + 100 * (p - 1)) - 1];
                st.site = &e_emlrtRSI;
                b_log(&st, &x);
                if (x > 0.0) {
                  b_x = rtInf;
                } else if (x < 0.0) {
                  b_x = rtMinusInf;
                } else {
                  b_x = rtNaN;
                }

                cost_sum += b_x;
              } else {
                q = path_list->size[0];
                if (!((i >= 1) && (i <= q))) {
                  emlrtDynamicBoundsCheckR2012b(i, 1, q, &ab_emlrtBCI, sp);
                }

                c = path_list->data[(i + path_list->size[0] * (k - 1)) - 1];
                if (c != (int32_T)muDoubleScalarFloor(c)) {
                  emlrtIntegerCheckR2012b(c, &j_emlrtDCI, sp);
                }

                q = (int32_T)c;
                if (!((q >= 1) && (q <= 100))) {
                  emlrtDynamicBoundsCheckR2012b(q, 1, 100, &y_emlrtBCI, sp);
                }

                p = path_list->size[0];
                if (!((i >= 1) && (i <= p))) {
                  emlrtDynamicBoundsCheckR2012b(i, 1, p, &ab_emlrtBCI, sp);
                }

                c = path_list->data[(i + path_list->size[0] * k) - 1];
                if (c != (int32_T)muDoubleScalarFloor(c)) {
                  emlrtIntegerCheckR2012b(c, &j_emlrtDCI, sp);
                }

                p = (int32_T)c;
                if (!((p >= 1) && (p <= 100))) {
                  emlrtDynamicBoundsCheckR2012b(p, 1, 100, &y_emlrtBCI, sp);
                }

                x = costs[(q + 100 * (p - 1)) - 1];
                st.site = &d_emlrtRSI;
                b_log(&st, &x);
                q = path_list->size[0];
                if (!((i >= 1) && (i <= q))) {
                  emlrtDynamicBoundsCheckR2012b(i, 1, q, &cb_emlrtBCI, sp);
                }

                c = path_list->data[(i + path_list->size[0] * k) - 1];
                if (c != (int32_T)muDoubleScalarFloor(c)) {
                  emlrtIntegerCheckR2012b(c, &k_emlrtDCI, sp);
                }

                q = (int32_T)c;
                if (!((q >= 1) && (q <= 100))) {
                  emlrtDynamicBoundsCheckR2012b(q, 1, 100, &bb_emlrtBCI, sp);
                }

                choice = rwd[q - 1];
                st.site = &d_emlrtRSI;
                b_log(&st, &choice);
                cost_sum += x / choice;
              }
            }
          }

          k++;
          if (*emlrtBreakCheckR2012bFlagVar != 0) {
            emlrtBreakCheckR2012b(sp);
          }
        }

        i2 = scores->size[0];
        q = scores->size[0];
        scores->size[0] = i2 + 1;
        emxEnsureCapacity_real_T1(sp, scores, q, &e_emlrtRTEI);
        scores->data[i2] = cost_sum;
        i++;
        if (*emlrtBreakCheckR2012bFlagVar != 0) {
          emlrtBreakCheckR2012b(sp);
        }
      }

      /* Sort the scores from lowest to highest (lower score is better) */
      st.site = &c_emlrtRSI;
      b_st.site = &o_emlrtRSI;
      sort(&b_st, scores, idx);
      q = b->size[0];
      b->size[0] = idx->size[0];
      emxEnsureCapacity_real_T1(&st, b, q, &f_emlrtRTEI);
      i2 = idx->size[0];
      for (q = 0; q < i2; q++) {
        b->data[q] = idx->data[q];
      }

      /* Append the score to the path list for ease of reference */
      q = scored_paths->size[0] * scored_paths->size[1];
      scored_paths->size[0] = (int32_T)N;
      scored_paths->size[1] = 101;
      emxEnsureCapacity_real_T(sp, scored_paths, q, &c_emlrtRTEI);
      i = 1;
      while (i - 1 <= (int32_T)N - 1) {
        q = path_list->size[0];
        p = b->size[0];
        if (!((i >= 1) && (i <= p))) {
          emlrtDynamicBoundsCheckR2012b(i, 1, p, &r_emlrtBCI, sp);
        }

        pEnd = (int32_T)b->data[i - 1];
        if (!((pEnd >= 1) && (pEnd <= q))) {
          emlrtDynamicBoundsCheckR2012b(pEnd, 1, q, &d_emlrtBCI, sp);
        }

        i2 = scored_paths->size[0];
        if (!((i >= 1) && (i <= i2))) {
          emlrtDynamicBoundsCheckR2012b(i, 1, i2, &c_emlrtBCI, sp);
        }

        q = scores->size[0];
        if (!((i >= 1) && (i <= q))) {
          emlrtDynamicBoundsCheckR2012b(i, 1, q, &s_emlrtBCI, sp);
        }

        scored_paths->data[i - 1] = scores->data[i - 1];
        for (q = 0; q < 100; q++) {
          scored_paths->data[(i + scored_paths->size[0] * (q + 1)) - 1] =
            path_list->data[(pEnd + path_list->size[0] * q) - 1];
        }

        i++;
        if (*emlrtBreakCheckR2012bFlagVar != 0) {
          emlrtBreakCheckR2012b(sp);
        }
      }

      /* Transition matrix update */
      for (q = 0; q < 10000; q++) {
        SD->f0.trans_mat_old[q] = trans_mat[q];
        trans_mat[q] = 0.0;
      }

      /* Select the top performing percentile of nodes from the paths */
      q = high_scored_paths->size[0] * high_scored_paths->size[1];
      high_scored_paths->size[0] = 255;
      high_scored_paths->size[1] = 101;
      emxEnsureCapacity_real_T(sp, high_scored_paths, q, &g_emlrtRTEI);
      for (q = 0; q < 101; q++) {
        for (p = 0; p < 255; p++) {
          high_scored_paths->data[p + high_scored_paths->size[0] * q] =
            scored_paths->data[p + scored_paths->size[0] * q];
        }
      }

      /* Transition matrix counter */
      i2 = 0;
      while (i2 <= 254) {
        pEnd = 2;
        while ((pEnd - 2 <= 97) && (!(scored_paths->data[i2 + scored_paths->
                 size[0] * (pEnd - 1)] == 0.0)) && (!(scored_paths->data[i2 +
                 scored_paths->size[0] * pEnd] == 0.0))) {
          /* Account for node paths that don't visit all nodes due to */
          /* budget contraints */
          c = scored_paths->data[i2 + scored_paths->size[0] * (pEnd - 1)];
          if (c != (int32_T)muDoubleScalarFloor(c)) {
            emlrtIntegerCheckR2012b(c, &f_emlrtDCI, sp);
          }

          q = (int32_T)c;
          if (!((q >= 1) && (q <= 100))) {
            emlrtDynamicBoundsCheckR2012b(q, 1, 100, &p_emlrtBCI, sp);
          }

          c = scored_paths->data[i2 + scored_paths->size[0] * pEnd];
          if (c != (int32_T)muDoubleScalarFloor(c)) {
            emlrtIntegerCheckR2012b(c, &f_emlrtDCI, sp);
          }

          p = (int32_T)c;
          if (!((p >= 1) && (p <= 100))) {
            emlrtDynamicBoundsCheckR2012b(p, 1, 100, &p_emlrtBCI, sp);
          }

          c = scored_paths->data[i2 + scored_paths->size[0] * (pEnd - 1)];
          if (c != (int32_T)muDoubleScalarFloor(c)) {
            emlrtIntegerCheckR2012b(c, &g_emlrtDCI, sp);
          }

          kEnd = (int32_T)c;
          if (!((kEnd >= 1) && (kEnd <= 100))) {
            emlrtDynamicBoundsCheckR2012b(kEnd, 1, 100, &q_emlrtBCI, sp);
          }

          c = scored_paths->data[i2 + scored_paths->size[0] * pEnd];
          if (c != (int32_T)muDoubleScalarFloor(c)) {
            emlrtIntegerCheckR2012b(c, &g_emlrtDCI, sp);
          }

          qEnd = (int32_T)c;
          if (!((qEnd >= 1) && (qEnd <= 100))) {
            emlrtDynamicBoundsCheckR2012b(qEnd, 1, 100, &q_emlrtBCI, sp);
          }

          trans_mat[(kEnd + 100 * (qEnd - 1)) - 1] = trans_mat[(q + 100 * (p - 1))
            - 1] + 1.0;
          pEnd++;
          if (*emlrtBreakCheckR2012bFlagVar != 0) {
            emlrtBreakCheckR2012b(sp);
          }
        }

        i2++;
        if (*emlrtBreakCheckR2012bFlagVar != 0) {
          emlrtBreakCheckR2012b(sp);
        }
      }

      /* Smoothly update the transition matrix */
      c_sum(trans_mat, trans_mat_old);
      memcpy(&b_trans_mat[0], &trans_mat[0], 10000U * sizeof(real_T));
      bsxfun(b_trans_mat, trans_mat_old, trans_mat);
      kEnd = 0;
      for (i = 0; i < 10000; i++) {
        overflow = muDoubleScalarIsNaN(trans_mat[i]);
        if (overflow) {
          kEnd++;
        }

        bv0[i] = overflow;
      }

      pEnd = 0;
      for (i = 0; i < 10000; i++) {
        if (bv0[i]) {
          b_tmp_data[pEnd] = (int16_T)(i + 1);
          pEnd++;
        }
      }

      for (q = 0; q < kEnd; q++) {
        trans_mat[b_tmp_data[q] - 1] = 0.0;
      }

      for (q = 0; q < 10000; q++) {
        trans_mat[q] = 0.5 * trans_mat[q] + 0.5 * SD->f0.trans_mat_old[q];
      }

      c_sum(trans_mat, trans_mat_old);
      memcpy(&b_trans_mat[0], &trans_mat[0], 10000U * sizeof(real_T));
      bsxfun(b_trans_mat, trans_mat_old, trans_mat);
      kEnd = 0;
      for (i = 0; i < 10000; i++) {
        overflow = muDoubleScalarIsNaN(trans_mat[i]);
        if (overflow) {
          kEnd++;
        }

        bv0[i] = overflow;
      }

      pEnd = 0;
      for (i = 0; i < 10000; i++) {
        if (bv0[i]) {
          c_tmp_data[pEnd] = (int16_T)(i + 1);
          pEnd++;
        }
      }

      for (q = 0; q < kEnd; q++) {
        trans_mat[c_tmp_data[q] - 1] = 0.0;
      }

      /* Optimisation performance metrics */
      i2 = gammas->size[1];
      q = gammas->size[0] * gammas->size[1];
      gammas->size[1] = i2 + 1;
      emxEnsureCapacity_real_T(sp, gammas, q, &e_emlrtRTEI);
      gammas->data[i2] = scored_paths->data[254];
      st.site = &b_emlrtRSI;
      b_st.site = &tb_emlrtRSI;
      na = scores->size[0];
      c_st.site = &ub_emlrtRSI;
      n = scores->size[0] + 1;
      i2 = scores->size[0];
      q = idx->size[0];
      idx->size[0] = i2;
      emxEnsureCapacity_int32_T(&c_st, idx, q, &h_emlrtRTEI);
      for (q = 0; q < i2; q++) {
        idx->data[q] = 0;
      }

      if (scores->size[0] != 0) {
        d_st.site = &ec_emlrtRSI;
        q = iwork->size[0];
        iwork->size[0] = i2;
        emxEnsureCapacity_int32_T(&d_st, iwork, q, &i_emlrtRTEI);
        e_st.site = &fc_emlrtRSI;
        overflow = ((!(1 > scores->size[0] - 1)) && (scores->size[0] - 1 >
          2147483645));
        if (overflow) {
          f_st.site = &w_emlrtRSI;
          check_forloop_overflow_error(&f_st);
        }

        for (k = 1; k <= n - 2; k += 2) {
          if ((scores->data[k - 1] <= scores->data[k]) || muDoubleScalarIsNaN
              (scores->data[k])) {
            idx->data[k - 1] = k;
            idx->data[k] = k + 1;
          } else {
            idx->data[k - 1] = k + 1;
            idx->data[k] = k;
          }
        }

        if ((scores->size[0] & 1) != 0) {
          idx->data[scores->size[0] - 1] = scores->size[0];
        }

        i = 2;
        while (i < n - 1) {
          i2 = i << 1;
          j = 1;
          for (pEnd = 1 + i; pEnd < n; pEnd = qEnd + i) {
            p = j;
            q = pEnd - 1;
            qEnd = j + i2;
            if (qEnd > n) {
              qEnd = n;
            }

            k = 0;
            kEnd = qEnd - j;
            while (k + 1 <= kEnd) {
              if ((scores->data[idx->data[p - 1] - 1] <= scores->data[idx->
                   data[q] - 1]) || muDoubleScalarIsNaN(scores->data[idx->data[q]
                   - 1])) {
                iwork->data[k] = idx->data[p - 1];
                p++;
                if (p == pEnd) {
                  while (q + 1 < qEnd) {
                    k++;
                    iwork->data[k] = idx->data[q];
                    q++;
                  }
                }
              } else {
                iwork->data[k] = idx->data[q];
                q++;
                if (q + 1 == qEnd) {
                  while (p < pEnd) {
                    k++;
                    iwork->data[k] = idx->data[p - 1];
                    p++;
                  }
                }
              }

              k++;
            }

            e_st.site = &gc_emlrtRSI;
            for (k = 0; k < kEnd; k++) {
              idx->data[(j + k) - 1] = iwork->data[k];
            }

            j = qEnd;
          }

          i = i2;
        }
      }

      scores_idx_0 = (uint32_T)scores->size[0];
      q = b->size[0];
      b->size[0] = (int32_T)scores_idx_0;
      emxEnsureCapacity_real_T1(&b_st, b, q, &j_emlrtRTEI);
      c_st.site = &vb_emlrtRSI;
      overflow = ((!(1 > scores->size[0])) && (scores->size[0] > 2147483646));
      if (overflow) {
        d_st.site = &w_emlrtRSI;
        check_forloop_overflow_error(&d_st);
      }

      for (k = 0; k < na; k++) {
        b->data[k] = scores->data[idx->data[k] - 1];
      }

      k = 0;
      while ((k + 1 <= na) && muDoubleScalarIsInf(b->data[k]) && (b->data[k] <
              0.0)) {
        k++;
      }

      q = k;
      k = scores->size[0];
      while ((k >= 1) && muDoubleScalarIsNaN(b->data[k - 1])) {
        k--;
      }

      kEnd = scores->size[0] - k;
      while ((k >= 1) && muDoubleScalarIsInf(b->data[k - 1]) && (b->data[k - 1] >
              0.0)) {
        k--;
      }

      qEnd = (scores->size[0] - k) - kEnd;
      p = 0;
      if (q > 0) {
        p = 1;
        c_st.site = &wb_emlrtRSI;
      }

      i2 = (q + k) - q;
      while (q + 1 <= i2) {
        x = b->data[q];
        pEnd = q;
        do {
          exitg2 = 0;
          q++;
          if (q + 1 > i2) {
            exitg2 = 1;
          } else {
            c_st.site = &xb_emlrtRSI;
            d_st.site = &hc_emlrtRSI;
            c = muDoubleScalarAbs(x / 2.0);
            if ((!muDoubleScalarIsInf(c)) && (!muDoubleScalarIsNaN(c))) {
              if (c <= 2.2250738585072014E-308) {
                c = 4.94065645841247E-324;
              } else {
                frexp(c, &exponent);
                c = ldexp(1.0, exponent - 53);
              }
            } else {
              c = rtNaN;
            }

            if ((muDoubleScalarAbs(x - b->data[q]) < c) || (muDoubleScalarIsInf
                 (b->data[q]) && muDoubleScalarIsInf(x) && ((b->data[q] > 0.0) ==
                  (x > 0.0)))) {
              overflow = true;
            } else {
              overflow = false;
            }

            if (!overflow) {
              exitg2 = 1;
            }
          }
        } while (exitg2 == 0);

        p++;
        b->data[p - 1] = x;
        c_st.site = &yb_emlrtRSI;
        if ((!(pEnd + 1 > q)) && (q > 2147483646)) {
          d_st.site = &w_emlrtRSI;
          check_forloop_overflow_error(&d_st);
        }
      }

      if (qEnd > 0) {
        p++;
        b->data[p - 1] = b->data[i2];
        c_st.site = &ac_emlrtRSI;
        if (qEnd > 2147483646) {
          d_st.site = &w_emlrtRSI;
          check_forloop_overflow_error(&d_st);
        }
      }

      q = i2 + qEnd;
      c_st.site = &bc_emlrtRSI;
      if ((!(1 > kEnd)) && (kEnd > 2147483646)) {
        d_st.site = &w_emlrtRSI;
        check_forloop_overflow_error(&d_st);
      }

      for (j = 1; j <= kEnd; j++) {
        p++;
        b->data[p - 1] = b->data[(q + j) - 1];
      }

      if (!(p <= scores->size[0])) {
        emlrtErrorWithMessageIdR2018a(&b_st, &v_emlrtRTEI,
          "Coder:builtins:AssertionFailed", "Coder:builtins:AssertionFailed", 0);
      }

      c_st.site = &cc_emlrtRSI;
      overflow = !(b->size[0] != 1);
      if (overflow) {
        overflow = false;
        if (1 > p) {
          i0 = 0;
        } else {
          i0 = p;
        }

        if (i0 != 1) {
          overflow = true;
        }

        if (overflow) {
          overflow = true;
        } else {
          overflow = false;
        }
      } else {
        overflow = false;
      }

      d_st.site = &ic_emlrtRSI;
      if (overflow) {
        emlrtErrorWithMessageIdR2018a(&d_st, &w_emlrtRTEI,
          "Coder:FE:PotentialVectorVector", "Coder:FE:PotentialVectorVector", 0);
      }

      c_st.site = &dc_emlrtRSI;
      if ((!(1 > p)) && (p > 2147483646)) {
        d_st.site = &w_emlrtRSI;
        check_forloop_overflow_error(&d_st);
      }

      /* Check for stopping condition, if the same optimisation performance */
      /* (gamma) occurred d times in a row then stop. */
      if (!(t < 5.0)) {
        q = gammas->size[1];
        p = gammas->size[1];
        if (!((p >= 1) && (p <= q))) {
          emlrtDynamicBoundsCheckR2012b(p, 1, q, &l_emlrtBCI, sp);
        }

        q = gammas->size[1];
        kEnd = gammas->size[1] - 1;
        if (!((kEnd >= 1) && (kEnd <= q))) {
          emlrtDynamicBoundsCheckR2012b(kEnd, 1, q, &m_emlrtBCI, sp);
        }

        if (gammas->data[p - 1] - gammas->data[kEnd - 1] < 0.1) {
          q = gammas->size[1];
          p = gammas->size[1];
          if (!((p >= 1) && (p <= q))) {
            emlrtDynamicBoundsCheckR2012b(p, 1, q, &n_emlrtBCI, sp);
          }

          q = gammas->size[1];
          kEnd = gammas->size[1] - 1;
          if (!((kEnd >= 1) && (kEnd <= q))) {
            emlrtDynamicBoundsCheckR2012b(kEnd, 1, q, &o_emlrtBCI, sp);
          }

          if (gammas->data[p - 1] >= gammas->data[kEnd - 1]) {
            while_cond = 0;
          }
        }
      }

      t++;
      if (*emlrtBreakCheckR2012bFlagVar != 0) {
        emlrtBreakCheckR2012b(sp);
      }
    } else {
      exitg1 = 1;
    }
  } while (exitg1 == 0);

  emxFree_int32_T(sp, &iwork);
  emxFree_int32_T(sp, &idx);
  emxFree_real_T(sp, &b);
  emxFree_real_T(sp, &scored_paths);
  emxFree_real_T(sp, &scores);
  emxFree_real_T(sp, &path_list);
  emxFree_real_T(sp, &gammas);
  if (2 > high_scored_paths->size[1]) {
    q = 0;
    kEnd = 0;
  } else {
    q = 1;
    p = high_scored_paths->size[1];
    kEnd = high_scored_paths->size[1];
    if (!((kEnd >= 1) && (kEnd <= p))) {
      emlrtDynamicBoundsCheckR2012b(kEnd, 1, p, &emlrtBCI, sp);
    }
  }

  p = high_scored_paths->size[0];
  if (!(1 <= p)) {
    emlrtDynamicBoundsCheckR2012b(1, 1, p, &b_emlrtBCI, sp);
  }

  ceTour_size[1] = kEnd - q;
  i2 = kEnd - q;
  for (p = 0; p < i2; p++) {
    ceTour_data[p] = high_scored_paths->data[high_scored_paths->size[0] * (q + p)];
  }

  i2 = (kEnd - q) - 1;
  kEnd = 0;
  for (i = 0; i <= i2; i++) {
    if (high_scored_paths->data[high_scored_paths->size[0] * (q + i)] != 0.0) {
      kEnd++;
    }
  }

  emxFree_real_T(sp, &high_scored_paths);
  pEnd = 0;
  for (i = 0; i <= i2; i++) {
    if (ceTour_data[i] != 0.0) {
      if (!((i + 1 >= 1) && (i + 1 <= ceTour_size[1]))) {
        emlrtDynamicBoundsCheckR2012b(i + 1, 1, ceTour_size[1], &j_emlrtBCI, sp);
      }

      ceTour_data[pEnd] = ceTour_data[i];
      pEnd++;
    }
  }

  ceTour_size[0] = 1;
  ceTour_size[1] = kEnd;
  rwd_original_size[0] = 1;
  rwd_original_size[1] = kEnd;
  for (q = 0; q < kEnd; q++) {
    if (ceTour_data[q] != (int32_T)muDoubleScalarFloor(ceTour_data[q])) {
      emlrtIntegerCheckR2012b(ceTour_data[q], &e_emlrtDCI, sp);
    }

    p = (int32_T)ceTour_data[q];
    if (!((p >= 1) && (p <= 100))) {
      emlrtDynamicBoundsCheckR2012b(p, 1, 100, &k_emlrtBCI, sp);
    }

    rwd_original_data[q] = rwd_original[p - 1];
  }

  st.site = &emlrtRSI;
  *ceReward = d_sum(&st, rwd_original_data, rwd_original_size);
  emlrtHeapReferenceStackLeaveFcnR2012b(sp);
}

/* End of code generation (ce_algo.c) */
