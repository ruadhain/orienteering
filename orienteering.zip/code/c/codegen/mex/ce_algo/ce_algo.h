/*
 * Student License - for use by students to meet course requirements and
 * perform academic research at degree granting institutions only.  Not
 * for government, commercial, or other organizational use.
 *
 * ce_algo.h
 *
 * Code generation for function 'ce_algo'
 *
 */

#ifndef CE_ALGO_H
#define CE_ALGO_H

/* Include files */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "rtwtypes.h"
#include "ce_algo_types.h"

/* Function Declarations */
extern void ce_algo(ce_algoStackData *SD, const emlrtStack *sp, real_T costs
                    [10000], real_T rwd[100], real_T BGT, real_T start_node,
                    const real_T init_trans_mat[10000], real_T *ceReward, real_T
                    ceTour_data[], int32_T ceTour_size[2], real_T trans_mat
                    [10000]);

#endif

/* End of code generation (ce_algo.h) */
