/*
 * Student License - for use by students to meet course requirements and
 * perform academic research at degree granting institutions only.  Not
 * for government, commercial, or other organizational use.
 *
 * randsample.c
 *
 * Code generation for function 'randsample'
 *
 */

/* Include files */
#include "mwmathutil.h"
#include "rt_nonfinite.h"
#include "ce_algo.h"
#include "randsample.h"

/* Variable Definitions */
static emlrtRSInfo n_emlrtRSI = { 91,  /* lineNo */
  "randsample",                        /* fcnName */
  "/Applications/MATLAB_R2018a.app/toolbox/stats/eml/randsample.m"/* pathName */
};

static emlrtRTEInfo y_emlrtRTEI = { 58,/* lineNo */
  31,                                  /* colNo */
  "randsample",                        /* fName */
  "/Applications/MATLAB_R2018a.app/toolbox/stats/eml/randsample.m"/* pName */
};

static emlrtRTEInfo ab_emlrtRTEI = { 60,/* lineNo */
  15,                                  /* colNo */
  "histc",                             /* fName */
  "/Applications/MATLAB_R2018a.app/toolbox/eml/lib/matlab/datafun/histc.m"/* pName */
};

/* Function Definitions */
real_T randsample(const emlrtStack *sp, const real_T varargin_4[100])
{
  real_T sumw;
  int32_T low_i;
  boolean_T guard1 = false;
  boolean_T p;
  real_T edges[101];
  boolean_T exitg1;
  int32_T low_ip1;
  int32_T high_i;
  int32_T mid_i;
  emlrtStack st;
  st.prev = sp;
  st.tls = sp->tls;
  sumw = varargin_4[0];
  for (low_i = 0; low_i < 99; low_i++) {
    sumw += varargin_4[low_i + 1];
  }

  guard1 = false;
  if (sumw > 0.0) {
    p = true;
    for (low_i = 0; low_i < 100; low_i++) {
      if (!(varargin_4[low_i] >= 0.0)) {
        p = false;
      }
    }

    if (p) {
    } else {
      guard1 = true;
    }
  } else {
    guard1 = true;
  }

  if (guard1) {
    emlrtErrorWithMessageIdR2018a(sp, &y_emlrtRTEI,
      "stats:randsample:InvalidWeights", "stats:randsample:InvalidWeights", 0);
  }

  edges[0] = 0.0;
  edges[100] = 1.0;
  for (low_i = 0; low_i < 99; low_i++) {
    edges[low_i + 1] = muDoubleScalarMin(edges[low_i] + varargin_4[low_i] / sumw,
      1.0);
  }

  emlrtRandu(&sumw, 1);
  st.site = &n_emlrtRSI;
  low_i = 1;
  exitg1 = false;
  while ((!exitg1) && (low_i + 1 < 102)) {
    if (!(edges[low_i] >= edges[low_i - 1])) {
      emlrtErrorWithMessageIdR2018a(&st, &ab_emlrtRTEI,
        "Coder:MATLAB:histc_InvalidInput3", "Coder:MATLAB:histc_InvalidInput3",
        0);
      exitg1 = true;
    } else {
      low_i++;
    }
  }

  low_i = 0;
  if (!muDoubleScalarIsNaN(sumw)) {
    if ((sumw >= edges[0]) && (sumw < edges[100])) {
      low_i = 1;
      low_ip1 = 2;
      high_i = 101;
      while (high_i > low_ip1) {
        mid_i = (low_i + high_i) >> 1;
        if (sumw >= edges[mid_i - 1]) {
          low_i = mid_i;
          low_ip1 = mid_i + 1;
        } else {
          high_i = mid_i;
        }
      }
    }

    if (sumw == edges[100]) {
      low_i = 101;
    }
  }

  return low_i;
}

/* End of code generation (randsample.c) */
