/*
 * Student License - for use by students to meet course requirements and
 * perform academic research at degree granting institutions only.  Not
 * for government, commercial, or other organizational use.
 *
 * ce_algo_realworld.c
 *
 * Code generation for function 'ce_algo_realworld'
 *
 */

/* Include files */
#include <math.h>
#include <string.h>
#include "mwmathutil.h"
#include "rt_nonfinite.h"
#include "ce_algo_realworld.h"
#include "ce_algo_realworld_emxutil.h"
#include "sum.h"
#include "log.h"
#include "randsample.h"
#include "bsxfun.h"
#include "eml_int_forloop_overflow_check.h"
#include "sort1.h"
#include "toLogicalCheck.h"
#include "diag.h"
#include "ce_algo_realworld_data.h"

/* Variable Definitions */
static emlrtRSInfo emlrtRSI = { 199,   /* lineNo */
  "ce_algo_realworld",                 /* fcnName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m"/* pathName */
};

static emlrtRSInfo b_emlrtRSI = { 184, /* lineNo */
  "ce_algo_realworld",                 /* fcnName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m"/* pathName */
};

static emlrtRSInfo c_emlrtRSI = { 142, /* lineNo */
  "ce_algo_realworld",                 /* fcnName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m"/* pathName */
};

static emlrtRSInfo d_emlrtRSI = { 135, /* lineNo */
  "ce_algo_realworld",                 /* fcnName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m"/* pathName */
};

static emlrtRSInfo e_emlrtRSI = { 133, /* lineNo */
  "ce_algo_realworld",                 /* fcnName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m"/* pathName */
};

static emlrtRSInfo f_emlrtRSI = { 99,  /* lineNo */
  "ce_algo_realworld",                 /* fcnName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m"/* pathName */
};

static emlrtRSInfo g_emlrtRSI = { 67,  /* lineNo */
  "ce_algo_realworld",                 /* fcnName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m"/* pathName */
};

static emlrtRSInfo h_emlrtRSI = { 63,  /* lineNo */
  "ce_algo_realworld",                 /* fcnName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m"/* pathName */
};

static emlrtRSInfo i_emlrtRSI = { 30,  /* lineNo */
  "ce_algo_realworld",                 /* fcnName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m"/* pathName */
};

static emlrtRSInfo k_emlrtRSI = { 40,  /* lineNo */
  "mpower",                            /* fcnName */
  "/Applications/MATLAB_R2018a.app/toolbox/eml/lib/matlab/ops/mpower.m"/* pathName */
};

static emlrtRSInfo l_emlrtRSI = { 49,  /* lineNo */
  "power",                             /* fcnName */
  "/Applications/MATLAB_R2018a.app/toolbox/eml/lib/matlab/ops/power.m"/* pathName */
};

static emlrtRSInfo o_emlrtRSI = { 23,  /* lineNo */
  "sort",                              /* fcnName */
  "/Applications/MATLAB_R2018a.app/toolbox/eml/lib/matlab/datafun/sort.m"/* pathName */
};

static emlrtRSInfo tb_emlrtRSI = { 44, /* lineNo */
  "unique",                            /* fcnName */
  "/Applications/MATLAB_R2018a.app/toolbox/eml/lib/matlab/ops/unique.m"/* pathName */
};

static emlrtRSInfo ub_emlrtRSI = { 152,/* lineNo */
  "unique",                            /* fcnName */
  "/Applications/MATLAB_R2018a.app/toolbox/eml/lib/matlab/ops/unique.m"/* pathName */
};

static emlrtRSInfo vb_emlrtRSI = { 154,/* lineNo */
  "unique",                            /* fcnName */
  "/Applications/MATLAB_R2018a.app/toolbox/eml/lib/matlab/ops/unique.m"/* pathName */
};

static emlrtRSInfo wb_emlrtRSI = { 163,/* lineNo */
  "unique",                            /* fcnName */
  "/Applications/MATLAB_R2018a.app/toolbox/eml/lib/matlab/ops/unique.m"/* pathName */
};

static emlrtRSInfo xb_emlrtRSI = { 181,/* lineNo */
  "unique",                            /* fcnName */
  "/Applications/MATLAB_R2018a.app/toolbox/eml/lib/matlab/ops/unique.m"/* pathName */
};

static emlrtRSInfo yb_emlrtRSI = { 188,/* lineNo */
  "unique",                            /* fcnName */
  "/Applications/MATLAB_R2018a.app/toolbox/eml/lib/matlab/ops/unique.m"/* pathName */
};

static emlrtRSInfo ac_emlrtRSI = { 201,/* lineNo */
  "unique",                            /* fcnName */
  "/Applications/MATLAB_R2018a.app/toolbox/eml/lib/matlab/ops/unique.m"/* pathName */
};

static emlrtRSInfo bc_emlrtRSI = { 212,/* lineNo */
  "unique",                            /* fcnName */
  "/Applications/MATLAB_R2018a.app/toolbox/eml/lib/matlab/ops/unique.m"/* pathName */
};

static emlrtRSInfo cc_emlrtRSI = { 220,/* lineNo */
  "unique",                            /* fcnName */
  "/Applications/MATLAB_R2018a.app/toolbox/eml/lib/matlab/ops/unique.m"/* pathName */
};

static emlrtRSInfo dc_emlrtRSI = { 226,/* lineNo */
  "unique",                            /* fcnName */
  "/Applications/MATLAB_R2018a.app/toolbox/eml/lib/matlab/ops/unique.m"/* pathName */
};

static emlrtRSInfo ec_emlrtRSI = { 145,/* lineNo */
  "sortIdx",                           /* fcnName */
  "/Applications/MATLAB_R2018a.app/toolbox/eml/eml/+coder/+internal/sortIdx.m"/* pathName */
};

static emlrtRSInfo fc_emlrtRSI = { 57, /* lineNo */
  "mergesort",                         /* fcnName */
  "/Applications/MATLAB_R2018a.app/toolbox/eml/eml/+coder/+internal/mergesort.m"/* pathName */
};

static emlrtRSInfo gc_emlrtRSI = { 112,/* lineNo */
  "mergesort",                         /* fcnName */
  "/Applications/MATLAB_R2018a.app/toolbox/eml/eml/+coder/+internal/mergesort.m"/* pathName */
};

static emlrtRSInfo hc_emlrtRSI = { 31, /* lineNo */
  "safeEq",                            /* fcnName */
  "/Applications/MATLAB_R2018a.app/toolbox/eml/eml/+coder/+internal/safeEq.m"/* pathName */
};

static emlrtRSInfo ic_emlrtRSI = { 18, /* lineNo */
  "indexShapeCheck",                   /* fcnName */
  "/Applications/MATLAB_R2018a.app/toolbox/eml/eml/+coder/+internal/indexShapeCheck.m"/* pathName */
};

static emlrtRTEInfo emlrtRTEI = { 54,  /* lineNo */
  1,                                   /* colNo */
  "ce_algo_realworld",                 /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m"/* pName */
};

static emlrtRTEInfo b_emlrtRTEI = { 58,/* lineNo */
  1,                                   /* colNo */
  "ce_algo_realworld",                 /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m"/* pName */
};

static emlrtRTEInfo c_emlrtRTEI = { 144,/* lineNo */
  20,                                  /* colNo */
  "ce_algo_realworld",                 /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m"/* pName */
};

static emlrtRTEInfo d_emlrtRTEI = { 123,/* lineNo */
  5,                                   /* colNo */
  "ce_algo_realworld",                 /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m"/* pName */
};

static emlrtRTEInfo e_emlrtRTEI = { 1, /* lineNo */
  42,                                  /* colNo */
  "ce_algo_realworld",                 /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m"/* pName */
};

static emlrtRTEInfo f_emlrtRTEI = { 24,/* lineNo */
  5,                                   /* colNo */
  "sort",                              /* fName */
  "/Applications/MATLAB_R2018a.app/toolbox/eml/lib/matlab/datafun/sort.m"/* pName */
};

static emlrtRTEInfo g_emlrtRTEI = { 154,/* lineNo */
  5,                                   /* colNo */
  "ce_algo_realworld",                 /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m"/* pName */
};

static emlrtRTEInfo h_emlrtRTEI = { 152,/* lineNo */
  1,                                   /* colNo */
  "unique",                            /* fName */
  "/Applications/MATLAB_R2018a.app/toolbox/eml/lib/matlab/ops/unique.m"/* pName */
};

static emlrtRTEInfo i_emlrtRTEI = { 145,/* lineNo */
  23,                                  /* colNo */
  "sortIdx",                           /* fName */
  "/Applications/MATLAB_R2018a.app/toolbox/eml/eml/+coder/+internal/sortIdx.m"/* pName */
};

static emlrtRTEInfo j_emlrtRTEI = { 44,/* lineNo */
  13,                                  /* colNo */
  "unique",                            /* fName */
  "/Applications/MATLAB_R2018a.app/toolbox/eml/lib/matlab/ops/unique.m"/* pName */
};

static emlrtRTEInfo k_emlrtRTEI = { 72,/* lineNo */
  5,                                   /* colNo */
  "ce_algo_realworld",                 /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m"/* pName */
};

static emlrtRTEInfo l_emlrtRTEI = { 144,/* lineNo */
  5,                                   /* colNo */
  "ce_algo_realworld",                 /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m"/* pName */
};

static emlrtRTEInfo m_emlrtRTEI = { 1, /* lineNo */
  11,                                  /* colNo */
  "unique",                            /* fName */
  "/Applications/MATLAB_R2018a.app/toolbox/eml/lib/matlab/ops/unique.m"/* pName */
};

static emlrtRTEInfo n_emlrtRTEI = { 52,/* lineNo */
  1,                                   /* colNo */
  "mergesort",                         /* fName */
  "/Applications/MATLAB_R2018a.app/toolbox/eml/eml/+coder/+internal/mergesort.m"/* pName */
};

static emlrtBCInfo emlrtBCI = { -1,    /* iFirst */
  -1,                                  /* iLast */
  197,                                 /* lineNo */
  32,                                  /* colNo */
  "high_scored_paths",                 /* aName */
  "ce_algo_realworld",                 /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo b_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  197,                                 /* lineNo */
  28,                                  /* colNo */
  "high_scored_paths",                 /* aName */
  "ce_algo_realworld",                 /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  160,                                 /* lineNo */
  35,                                  /* colNo */
  "high_scored_paths",                 /* aName */
  "ce_algo_realworld",                 /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo d_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  159,                                 /* lineNo */
  35,                                  /* colNo */
  "high_scored_paths",                 /* aName */
  "ce_algo_realworld",                 /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo e_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  154,                                 /* lineNo */
  40,                                  /* colNo */
  "scored_paths",                      /* aName */
  "ce_algo_realworld",                 /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo f_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  146,                                 /* lineNo */
  22,                                  /* colNo */
  "scored_paths",                      /* aName */
  "ce_algo_realworld",                 /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo g_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  146,                                 /* lineNo */
  46,                                  /* colNo */
  "path_list",                         /* aName */
  "ce_algo_realworld",                 /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo h_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  126,                                 /* lineNo */
  36,                                  /* colNo */
  "path_list",                         /* aName */
  "ce_algo_realworld",                 /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo i_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  118,                                 /* lineNo */
  19,                                  /* colNo */
  "path_list",                         /* aName */
  "ce_algo_realworld",                 /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo j_emlrtBCI = { 1,   /* iFirst */
  34,                                  /* iLast */
  103,                                 /* lineNo */
  47,                                  /* colNo */
  "normal_costs",                      /* aName */
  "ce_algo_realworld",                 /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo emlrtDCI = { 103,   /* lineNo */
  47,                                  /* colNo */
  "ce_algo_realworld",                 /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo k_emlrtBCI = { 1,   /* iFirst */
  34,                                  /* iLast */
  99,                                  /* lineNo */
  57,                                  /* colNo */
  "temp_trans_mat",                    /* aName */
  "ce_algo_realworld",                 /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo b_emlrtDCI = { 99,  /* lineNo */
  57,                                  /* colNo */
  "ce_algo_realworld",                 /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo l_emlrtBCI = { 1,   /* iFirst */
  34,                                  /* iLast */
  93,                                  /* lineNo */
  31,                                  /* colNo */
  "temp_trans_mat",                    /* aName */
  "ce_algo_realworld",                 /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m",/* pName */
  3                                    /* checkKind */
};

static emlrtDCInfo c_emlrtDCI = { 93,  /* lineNo */
  31,                                  /* colNo */
  "ce_algo_realworld",                 /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m",/* pName */
  1                                    /* checkKind */
};

static emlrtDCInfo d_emlrtDCI = { 72,  /* lineNo */
  23,                                  /* colNo */
  "ce_algo_realworld",                 /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m",/* pName */
  1                                    /* checkKind */
};

static emlrtRTEInfo v_emlrtRTEI = { 219,/* lineNo */
  1,                                   /* colNo */
  "unique",                            /* fName */
  "/Applications/MATLAB_R2018a.app/toolbox/eml/lib/matlab/ops/unique.m"/* pName */
};

static emlrtRTEInfo w_emlrtRTEI = { 88,/* lineNo */
  9,                                   /* colNo */
  "indexShapeCheck",                   /* fName */
  "/Applications/MATLAB_R2018a.app/toolbox/eml/eml/+coder/+internal/indexShapeCheck.m"/* pName */
};

static emlrtBCInfo m_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  198,                                 /* lineNo */
  10,                                  /* colNo */
  "ceTour",                            /* aName */
  "ce_algo_realworld",                 /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo n_emlrtBCI = { 1,   /* iFirst */
  34,                                  /* iLast */
  199,                                 /* lineNo */
  29,                                  /* colNo */
  "rwd_original",                      /* aName */
  "ce_algo_realworld",                 /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo e_emlrtDCI = { 199, /* lineNo */
  29,                                  /* colNo */
  "ce_algo_realworld",                 /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo o_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  181,                                 /* lineNo */
  23,                                  /* colNo */
  "scored_paths",                      /* aName */
  "ce_algo_realworld",                 /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo p_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  190,                                 /* lineNo */
  13,                                  /* colNo */
  "gammas",                            /* aName */
  "ce_algo_realworld",                 /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo q_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  190,                                 /* lineNo */
  27,                                  /* colNo */
  "gammas",                            /* aName */
  "ce_algo_realworld",                 /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo r_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  190,                                 /* lineNo */
  56,                                  /* colNo */
  "gammas",                            /* aName */
  "ce_algo_realworld",                 /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo s_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  190,                                 /* lineNo */
  71,                                  /* colNo */
  "gammas",                            /* aName */
  "ce_algo_realworld",                 /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo t_emlrtBCI = { 1,   /* iFirst */
  34,                                  /* iLast */
  166,                                 /* lineNo */
  34,                                  /* colNo */
  "trans_mat",                         /* aName */
  "ce_algo_realworld",                 /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo f_emlrtDCI = { 166, /* lineNo */
  34,                                  /* colNo */
  "ce_algo_realworld",                 /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo u_emlrtBCI = { 1,   /* iFirst */
  34,                                  /* iLast */
  166,                                 /* lineNo */
  17,                                  /* colNo */
  "trans_mat",                         /* aName */
  "ce_algo_realworld",                 /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m",/* pName */
  3                                    /* checkKind */
};

static emlrtDCInfo g_emlrtDCI = { 166, /* lineNo */
  17,                                  /* colNo */
  "ce_algo_realworld",                 /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo v_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  146,                                 /* lineNo */
  46,                                  /* colNo */
  "I",                                 /* aName */
  "ce_algo_realworld",                 /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo w_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  146,                                 /* lineNo */
  30,                                  /* colNo */
  "B",                                 /* aName */
  "ce_algo_realworld",                 /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo x_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  127,                                 /* lineNo */
  17,                                  /* colNo */
  "path_list",                         /* aName */
  "ce_algo_realworld",                 /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo y_emlrtBCI = { 1,   /* iFirst */
  34,                                  /* iLast */
  130,                                 /* lineNo */
  21,                                  /* colNo */
  "rwd",                               /* aName */
  "ce_algo_realworld",                 /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo h_emlrtDCI = { 130, /* lineNo */
  21,                                  /* colNo */
  "ce_algo_realworld",                 /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo ab_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  130,                                 /* lineNo */
  21,                                  /* colNo */
  "path_list",                         /* aName */
  "ce_algo_realworld",                 /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo bb_emlrtBCI = { 1,  /* iFirst */
  34,                                  /* iLast */
  132,                                 /* lineNo */
  25,                                  /* colNo */
  "rwd",                               /* aName */
  "ce_algo_realworld",                 /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo i_emlrtDCI = { 132, /* lineNo */
  25,                                  /* colNo */
  "ce_algo_realworld",                 /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo cb_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  132,                                 /* lineNo */
  25,                                  /* colNo */
  "path_list",                         /* aName */
  "ce_algo_realworld",                 /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo db_emlrtBCI = { 1,  /* iFirst */
  34,                                  /* iLast */
  135,                                 /* lineNo */
  47,                                  /* colNo */
  "costs",                             /* aName */
  "ce_algo_realworld",                 /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo j_emlrtDCI = { 135, /* lineNo */
  47,                                  /* colNo */
  "ce_algo_realworld",                 /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo eb_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  135,                                 /* lineNo */
  47,                                  /* colNo */
  "path_list",                         /* aName */
  "ce_algo_realworld",                 /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo fb_emlrtBCI = { 1,  /* iFirst */
  34,                                  /* iLast */
  135,                                 /* lineNo */
  92,                                  /* colNo */
  "rwd",                               /* aName */
  "ce_algo_realworld",                 /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo k_emlrtDCI = { 135, /* lineNo */
  92,                                  /* colNo */
  "ce_algo_realworld",                 /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo gb_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  135,                                 /* lineNo */
  92,                                  /* colNo */
  "path_list",                         /* aName */
  "ce_algo_realworld",                 /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo hb_emlrtBCI = { 1,  /* iFirst */
  34,                                  /* iLast */
  133,                                 /* lineNo */
  47,                                  /* colNo */
  "costs",                             /* aName */
  "ce_algo_realworld",                 /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo l_emlrtDCI = { 133, /* lineNo */
  47,                                  /* colNo */
  "ce_algo_realworld",                 /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo ib_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  133,                                 /* lineNo */
  47,                                  /* colNo */
  "path_list",                         /* aName */
  "ce_algo_realworld",                 /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo jb_emlrtBCI = { 1,  /* iFirst */
  34,                                  /* iLast */
  101,                                 /* lineNo */
  24,                                  /* colNo */
  "normal_costs",                      /* aName */
  "ce_algo_realworld",                 /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo m_emlrtDCI = { 101, /* lineNo */
  24,                                  /* colNo */
  "ce_algo_realworld",                 /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo kb_emlrtBCI = { 1,  /* iFirst */
  34,                                  /* iLast */
  110,                                 /* lineNo */
  17,                                  /* colNo */
  "path",                              /* aName */
  "ce_algo_realworld",                 /* fName */
  "/Users/my-account-name/Desktop/msc/PROJECT/code/project/ce_algo_realworld.m",/* pName */
  3                                    /* checkKind */
};

/* Function Definitions */
void ce_algo_realworld(const emlrtStack *sp, real_T costs[1156], real_T rwd[34],
  real_T BGT, real_T start_node, const real_T init_trans_mat[1156], real_T
  *ceReward, real_T ceTour_data[], int32_T ceTour_size[2], real_T trans_mat[1156])
{
  real_T c;
  real_T normal_costs[1156];
  int32_T i;
  int32_T j;
  real_T choice;
  real_T trans_mat_old[34];
  real_T rwd_original[34];
  real_T dv0[34];
  real_T b_trans_mat_old[1156];
  real_T x;
  emxArray_real_T *gammas;
  emxArray_real_T *high_scored_paths;
  int32_T while_cond;
  real_T N;
  real_T t;
  emxArray_real_T *path_list;
  emxArray_real_T *scores;
  emxArray_real_T *scored_paths;
  emxArray_real_T *b;
  emxArray_int32_T *idx;
  emxArray_int32_T *iwork;
  int32_T exitg1;
  uint8_T rho_quantile_idx;
  int32_T q;
  int32_T p;
  int32_T i2;
  real_T path[34];
  int32_T kEnd;
  real_T cost_sum;
  int32_T qEnd;
  int32_T pEnd;
  int32_T k;
  int32_T rwd_original_size[1];
  real_T rwd_original_data[35];
  real_T b_trans_mat[1156];
  boolean_T overflow;
  boolean_T bv0[1156];
  int16_T tmp_data[1156];
  boolean_T exitg2;
  int16_T b_tmp_data[1156];
  real_T b_x;
  int16_T c_tmp_data[1156];
  int32_T na;
  int32_T n;
  uint32_T scores_idx_0;
  int32_T exitg3;
  int32_T exponent;
  int32_T i0;
  emlrtStack st;
  emlrtStack b_st;
  emlrtStack c_st;
  emlrtStack d_st;
  emlrtStack e_st;
  emlrtStack f_st;
  st.prev = sp;
  st.tls = sp->tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  c_st.prev = &b_st;
  c_st.tls = b_st.tls;
  d_st.prev = &c_st;
  d_st.tls = c_st.tls;
  e_st.prev = &d_st;
  e_st.tls = d_st.tls;
  f_st.prev = &e_st;
  f_st.tls = e_st.tls;
  emlrtHeapReferenceStackEnterFcnR2012b(sp);

  /* Experimental parameters */
  c = 1.0;

  /* Batch size */
  /* Percentile cut-off for top performing paths */
  /* Update rate */
  /* Stopping criterion  */
  memcpy(&normal_costs[0], &costs[0], 1156U * sizeof(real_T));

  /* Normalise cost matrix */
  i = 0;
  while (i < 34) {
    for (j = 0; j < 34; j++) {
      trans_mat_old[j] = costs[i + 34 * j];
    }

    choice = sum(trans_mat_old);
    for (j = 0; j < 34; j++) {
      costs[i + 34 * j] /= choice;
    }

    i++;
    if (*emlrtBreakCheckR2012bFlagVar != 0) {
      emlrtBreakCheckR2012b(sp);
    }
  }

  /* Normalise rwd matrix */
  choice = b_sum(rwd);
  for (i = 0; i < 34; i++) {
    rwd_original[i] = rwd[i];
    rwd[i] /= choice;
  }

  /* Transition matrix initialisation  */
  memset(&trans_mat[0], 0, 1156U * sizeof(real_T));
  i = 0;
  while (i < 34) {
    j = 0;
    while (j < 34) {
      if (costs[i + 34 * j] != 0.0) {
        if (rwd[j] == 0.0) {
          trans_mat[i + 34 * j] = 0.0;
        } else if (rwd[j] == 1.0) {
          rwd[j] = 1.0;
        } else {
          x = costs[i + 34 * j];
          st.site = &i_emlrtRSI;
          b_log(&st, &x);
          choice = rwd[j];
          st.site = &i_emlrtRSI;
          b_log(&st, &choice);
          trans_mat[i + 34 * j] = x / choice;
        }
      }

      j++;
      if (*emlrtBreakCheckR2012bFlagVar != 0) {
        emlrtBreakCheckR2012b(sp);
      }
    }

    i++;
    if (*emlrtBreakCheckR2012bFlagVar != 0) {
      emlrtBreakCheckR2012b(sp);
    }
  }

  c_sum(init_trans_mat, dv0);
  if (sum(dv0) != 0.0) {
    c = 0.1;
    for (j = 0; j < 1156; j++) {
      trans_mat[j] = 0.5 * trans_mat[j] + 0.5 * init_trans_mat[j];
    }
  }

  /* Remove diagonal elements from transition matrix and then renormalise */
  /* (don't want to transition from same node twice) */
  diag(trans_mat, trans_mat_old);
  b_diag(trans_mat_old, b_trans_mat_old);
  for (j = 0; j < 1156; j++) {
    trans_mat[j] -= b_trans_mat_old[j];
  }

  i = 0;
  while (i < 34) {
    for (j = 0; j < 34; j++) {
      trans_mat_old[j] = trans_mat[i + 34 * j];
    }

    choice = sum(trans_mat_old);
    for (j = 0; j < 34; j++) {
      trans_mat[i + 34 * j] /= choice;
    }

    i++;
    if (*emlrtBreakCheckR2012bFlagVar != 0) {
      emlrtBreakCheckR2012b(sp);
    }
  }

  emxInit_real_T(sp, &gammas, 2, &emlrtRTEI, true);
  emxInit_real_T(sp, &high_scored_paths, 2, &b_emlrtRTEI, true);

  /* Reserves space not only for a new matrix but */
  /* also for a matrix from the previous iteration:   */
  /* Performance metrics     */
  j = gammas->size[0] * gammas->size[1];
  gammas->size[0] = 1;
  gammas->size[1] = 0;
  emxEnsureCapacity_real_T(sp, gammas, j, &emlrtRTEI);
  j = high_scored_paths->size[0] * high_scored_paths->size[1];
  high_scored_paths->size[0] = 0;
  high_scored_paths->size[1] = 0;
  emxEnsureCapacity_real_T(sp, high_scored_paths, j, &b_emlrtRTEI);
  while_cond = 1;

  /* While loop vars */
  st.site = &h_emlrtRSI;
  b_st.site = &k_emlrtRSI;
  c_st.site = &l_emlrtRSI;
  N = c * 1156.0;
  t = 0.0;
  emxInit_real_T(sp, &path_list, 2, &k_emlrtRTEI, true);
  emxInit_real_T1(sp, &scores, 1, &d_emlrtRTEI, true);
  emxInit_real_T(sp, &scored_paths, 2, &l_emlrtRTEI, true);
  emxInit_real_T1(sp, &b, 1, &m_emlrtRTEI, true);
  emxInit_int32_T(sp, &idx, 1, &h_emlrtRTEI, true);
  emxInit_int32_T(sp, &iwork, 1, &n_emlrtRTEI, true);
  do {
    exitg1 = 0;
    st.site = &g_emlrtRSI;
    toLogicalCheck(&st, while_cond);
    if (while_cond != 0) {
      /* rho is used to select the top percentile of best performing paths to */
      /* update the transition matrix probabilities with */
      j = (int32_T)muDoubleScalarRound(0.3 * N + 1.0);
      if (j < 256) {
        rho_quantile_idx = (uint8_T)j;
      } else {
        rho_quantile_idx = MAX_uint8_T;
      }

      if (N != muDoubleScalarFloor(N)) {
        emlrtIntegerCheckR2012b(N, &d_emlrtDCI, sp);
      }

      /* N is the number of paths to generate in this batch */
      j = path_list->size[0] * path_list->size[1];
      path_list->size[0] = (int32_T)N;
      path_list->size[1] = 34;
      emxEnsureCapacity_real_T(sp, path_list, j, &c_emlrtRTEI);
      i = 0;
      while (i <= (int32_T)N - 1) {
        /* Initialise vars */
        memcpy(&b_trans_mat_old[0], &trans_mat[0], 1156U * sizeof(real_T));
        memset(&path[0], 0, 34U * sizeof(real_T));

        /* Origin node */
        path[0] = start_node;

        /* Node counter used to handle the case where budget runs out before */
        /* visiting all nodes */
        qEnd = 0;

        /* Sum of total cost of transitions between nodes */
        c = 0.0;

        /* First node choice is the origin */
        choice = start_node;

        /* n is the number of possible nodes to be visited once */
        k = 0;
        while (k < 33) {
          /* This ensures that this node isn't visited again (note that it doesn't */
          /* mean that it can't be passed over en route to another node) */
          if (choice != (int32_T)muDoubleScalarFloor(choice)) {
            emlrtIntegerCheckR2012b(choice, &c_emlrtDCI, sp);
          }

          j = (int32_T)choice;
          if (!((j >= 1) && (j <= 34))) {
            emlrtDynamicBoundsCheckR2012b(j, 1, 34, &l_emlrtBCI, sp);
          }

          memset(&b_trans_mat_old[(int32_T)choice * 34 + -34], 0, 34U * sizeof
                 (real_T));

          /* Renormalise the transition matrix */
          d_sum(b_trans_mat_old, trans_mat_old);
          memcpy(&b_trans_mat[0], &b_trans_mat_old[0], 1156U * sizeof(real_T));
          bsxfun(b_trans_mat, trans_mat_old, b_trans_mat_old);
          kEnd = 0;
          for (i2 = 0; i2 < 1156; i2++) {
            overflow = muDoubleScalarIsNaN(b_trans_mat_old[i2]);
            if (overflow) {
              kEnd++;
            }

            bv0[i2] = overflow;
          }

          pEnd = 0;
          for (i2 = 0; i2 < 1156; i2++) {
            if (bv0[i2]) {
              tmp_data[pEnd] = (int16_T)(i2 + 1);
              pEnd++;
            }
          }

          for (j = 0; j < kEnd; j++) {
            b_trans_mat_old[tmp_data[j] - 1] = 0.0;
          }

          /* Randomly sample the node transition */
          if (path[qEnd] != (int32_T)muDoubleScalarFloor(path[qEnd])) {
            emlrtIntegerCheckR2012b(path[qEnd], &b_emlrtDCI, sp);
          }

          j = (int32_T)path[qEnd];
          if (!((j >= 1) && (j <= 34))) {
            emlrtDynamicBoundsCheckR2012b(j, 1, 34, &k_emlrtBCI, sp);
          }

          for (j = 0; j < 34; j++) {
            trans_mat_old[j] = b_trans_mat_old[((int32_T)path[qEnd] + 34 * j) -
              1];
          }

          st.site = &f_emlrtRSI;
          choice = randsample(&st, trans_mat_old);

          /* Cost of this transition */
          if (path[qEnd] != (int32_T)muDoubleScalarFloor(path[qEnd])) {
            emlrtIntegerCheckR2012b(path[qEnd], &m_emlrtDCI, sp);
          }

          j = (int32_T)path[qEnd];
          if (!((j >= 1) && (j <= 34))) {
            emlrtDynamicBoundsCheckR2012b(j, 1, 34, &jb_emlrtBCI, sp);
          }

          q = (int32_T)choice;
          if (!((q >= 1) && (q <= 34))) {
            emlrtDynamicBoundsCheckR2012b(q, 1, 34, &jb_emlrtBCI, sp);
          }

          cost_sum = normal_costs[(j + 34 * (q - 1)) - 1];

          /* Cost of returning the origin from this transition */
          if (path[0] != (int32_T)muDoubleScalarFloor(path[0])) {
            emlrtIntegerCheckR2012b(path[0], &emlrtDCI, sp);
          }

          j = (int32_T)path[0];
          if (!((j >= 1) && (j <= 34))) {
            emlrtDynamicBoundsCheckR2012b(j, 1, 34, &j_emlrtBCI, sp);
          }

          /* Ensure that the budget isn't expended, if it isn't then */
          /* include this node in the path and update the running total */
          /* cost */
          if ((c + normal_costs[((int32_T)path[qEnd] + 34 * ((int32_T)choice - 1))
               - 1]) + normal_costs[((int32_T)choice + 34 * ((int32_T)path[0] -
                1)) - 1] <= BGT) {
            qEnd++;
            if (!((qEnd + 1 >= 1) && (qEnd + 1 <= 34))) {
              emlrtDynamicBoundsCheckR2012b(qEnd + 1, 1, 34, &kb_emlrtBCI, sp);
            }

            path[qEnd] = choice;
            c += cost_sum;
          }

          k++;
          if (*emlrtBreakCheckR2012bFlagVar != 0) {
            emlrtBreakCheckR2012b(sp);
          }
        }

        /* Ensures that the final node visited is the origin */
        path[qEnd] = path[0];

        /* Add this path to the batch of paths */
        i2 = path_list->size[0];
        if (!(i + 1 <= i2)) {
          emlrtDynamicBoundsCheckR2012b(i + 1, 1, i2, &i_emlrtBCI, sp);
        }

        for (j = 0; j < 34; j++) {
          path_list->data[i + path_list->size[0] * j] = path[j];
        }

        i++;
        if (*emlrtBreakCheckR2012bFlagVar != 0) {
          emlrtBreakCheckR2012b(sp);
        }
      }

      /* Calculate the path scores based on time travelled and reward at nodes */
      j = scores->size[0];
      scores->size[0] = 0;
      emxEnsureCapacity_real_T1(sp, scores, j, &d_emlrtRTEI);
      i = 1;
      while (i - 1 <= (int32_T)N - 1) {
        cost_sum = 0.0;
        j = path_list->size[0];
        q = (i - 1) + 1;
        if (!((q >= 1) && (q <= j))) {
          emlrtDynamicBoundsCheckR2012b(q, 1, j, &h_emlrtBCI, sp);
        }

        k = 1;
        while (k - 1 < 33) {
          j = path_list->size[0];
          if (!((i >= 1) && (i <= j))) {
            emlrtDynamicBoundsCheckR2012b(i, 1, j, &x_emlrtBCI, sp);
          }

          if (path_list->data[(i + path_list->size[0] * k) - 1] != 0.0) {
            /* The optimisation goal is to minimise this cost function -> */
            /* log(travel time between nodes) / log(reward at each node) */
            j = path_list->size[0];
            if (!((i >= 1) && (i <= j))) {
              emlrtDynamicBoundsCheckR2012b(i, 1, j, &ab_emlrtBCI, sp);
            }

            c = path_list->data[(i + path_list->size[0] * k) - 1];
            if (c != (int32_T)muDoubleScalarFloor(c)) {
              emlrtIntegerCheckR2012b(c, &h_emlrtDCI, sp);
            }

            j = (int32_T)c;
            if (!((j >= 1) && (j <= 34))) {
              emlrtDynamicBoundsCheckR2012b(j, 1, 34, &y_emlrtBCI, sp);
            }

            if (rwd[j - 1] == 0.0) {
            } else {
              j = path_list->size[0];
              if (!((i >= 1) && (i <= j))) {
                emlrtDynamicBoundsCheckR2012b(i, 1, j, &cb_emlrtBCI, sp);
              }

              c = path_list->data[(i + path_list->size[0] * k) - 1];
              if (c != (int32_T)muDoubleScalarFloor(c)) {
                emlrtIntegerCheckR2012b(c, &i_emlrtDCI, sp);
              }

              j = (int32_T)c;
              if (!((j >= 1) && (j <= 34))) {
                emlrtDynamicBoundsCheckR2012b(j, 1, 34, &bb_emlrtBCI, sp);
              }

              if (rwd[j - 1] == 1.0) {
                j = path_list->size[0];
                if (!((i >= 1) && (i <= j))) {
                  emlrtDynamicBoundsCheckR2012b(i, 1, j, &ib_emlrtBCI, sp);
                }

                c = path_list->data[(i + path_list->size[0] * (k - 1)) - 1];
                if (c != (int32_T)muDoubleScalarFloor(c)) {
                  emlrtIntegerCheckR2012b(c, &l_emlrtDCI, sp);
                }

                j = (int32_T)c;
                if (!((j >= 1) && (j <= 34))) {
                  emlrtDynamicBoundsCheckR2012b(j, 1, 34, &hb_emlrtBCI, sp);
                }

                q = path_list->size[0];
                if (!((i >= 1) && (i <= q))) {
                  emlrtDynamicBoundsCheckR2012b(i, 1, q, &ib_emlrtBCI, sp);
                }

                c = path_list->data[(i + path_list->size[0] * k) - 1];
                if (c != (int32_T)muDoubleScalarFloor(c)) {
                  emlrtIntegerCheckR2012b(c, &l_emlrtDCI, sp);
                }

                q = (int32_T)c;
                if (!((q >= 1) && (q <= 34))) {
                  emlrtDynamicBoundsCheckR2012b(q, 1, 34, &hb_emlrtBCI, sp);
                }

                x = costs[(j + 34 * (q - 1)) - 1];
                st.site = &e_emlrtRSI;
                b_log(&st, &x);
                if (x > 0.0) {
                  b_x = rtInf;
                } else if (x < 0.0) {
                  b_x = rtMinusInf;
                } else {
                  b_x = rtNaN;
                }

                cost_sum += b_x;
              } else {
                j = path_list->size[0];
                if (!((i >= 1) && (i <= j))) {
                  emlrtDynamicBoundsCheckR2012b(i, 1, j, &eb_emlrtBCI, sp);
                }

                c = path_list->data[(i + path_list->size[0] * (k - 1)) - 1];
                if (c != (int32_T)muDoubleScalarFloor(c)) {
                  emlrtIntegerCheckR2012b(c, &j_emlrtDCI, sp);
                }

                j = (int32_T)c;
                if (!((j >= 1) && (j <= 34))) {
                  emlrtDynamicBoundsCheckR2012b(j, 1, 34, &db_emlrtBCI, sp);
                }

                q = path_list->size[0];
                if (!((i >= 1) && (i <= q))) {
                  emlrtDynamicBoundsCheckR2012b(i, 1, q, &eb_emlrtBCI, sp);
                }

                c = path_list->data[(i + path_list->size[0] * k) - 1];
                if (c != (int32_T)muDoubleScalarFloor(c)) {
                  emlrtIntegerCheckR2012b(c, &j_emlrtDCI, sp);
                }

                q = (int32_T)c;
                if (!((q >= 1) && (q <= 34))) {
                  emlrtDynamicBoundsCheckR2012b(q, 1, 34, &db_emlrtBCI, sp);
                }

                x = costs[(j + 34 * (q - 1)) - 1];
                st.site = &d_emlrtRSI;
                b_log(&st, &x);
                j = path_list->size[0];
                if (!((i >= 1) && (i <= j))) {
                  emlrtDynamicBoundsCheckR2012b(i, 1, j, &gb_emlrtBCI, sp);
                }

                c = path_list->data[(i + path_list->size[0] * k) - 1];
                if (c != (int32_T)muDoubleScalarFloor(c)) {
                  emlrtIntegerCheckR2012b(c, &k_emlrtDCI, sp);
                }

                j = (int32_T)c;
                if (!((j >= 1) && (j <= 34))) {
                  emlrtDynamicBoundsCheckR2012b(j, 1, 34, &fb_emlrtBCI, sp);
                }

                choice = rwd[j - 1];
                st.site = &d_emlrtRSI;
                b_log(&st, &choice);
                cost_sum += x / choice;
              }
            }
          }

          k++;
          if (*emlrtBreakCheckR2012bFlagVar != 0) {
            emlrtBreakCheckR2012b(sp);
          }
        }

        i2 = scores->size[0];
        j = scores->size[0];
        scores->size[0] = i2 + 1;
        emxEnsureCapacity_real_T1(sp, scores, j, &e_emlrtRTEI);
        scores->data[i2] = cost_sum;
        i++;
        if (*emlrtBreakCheckR2012bFlagVar != 0) {
          emlrtBreakCheckR2012b(sp);
        }
      }

      /* Sort the scores from lowest to highest (lower score is better) */
      st.site = &c_emlrtRSI;
      b_st.site = &o_emlrtRSI;
      sort(&b_st, scores, idx);
      j = b->size[0];
      b->size[0] = idx->size[0];
      emxEnsureCapacity_real_T1(&st, b, j, &f_emlrtRTEI);
      i2 = idx->size[0];
      for (j = 0; j < i2; j++) {
        b->data[j] = idx->data[j];
      }

      /* Append the score to the path list for ease of reference */
      j = scored_paths->size[0] * scored_paths->size[1];
      scored_paths->size[0] = (int32_T)N;
      scored_paths->size[1] = 35;
      emxEnsureCapacity_real_T(sp, scored_paths, j, &c_emlrtRTEI);
      i = 1;
      while (i - 1 <= (int32_T)N - 1) {
        j = path_list->size[0];
        q = b->size[0];
        if (!((i >= 1) && (i <= q))) {
          emlrtDynamicBoundsCheckR2012b(i, 1, q, &v_emlrtBCI, sp);
        }

        pEnd = (int32_T)b->data[i - 1];
        if (!((pEnd >= 1) && (pEnd <= j))) {
          emlrtDynamicBoundsCheckR2012b(pEnd, 1, j, &g_emlrtBCI, sp);
        }

        i2 = scored_paths->size[0];
        if (!((i >= 1) && (i <= i2))) {
          emlrtDynamicBoundsCheckR2012b(i, 1, i2, &f_emlrtBCI, sp);
        }

        j = scores->size[0];
        if (!((i >= 1) && (i <= j))) {
          emlrtDynamicBoundsCheckR2012b(i, 1, j, &w_emlrtBCI, sp);
        }

        scored_paths->data[i - 1] = scores->data[i - 1];
        for (j = 0; j < 34; j++) {
          scored_paths->data[(i + scored_paths->size[0] * (j + 1)) - 1] =
            path_list->data[(pEnd + path_list->size[0] * j) - 1];
        }

        i++;
        if (*emlrtBreakCheckR2012bFlagVar != 0) {
          emlrtBreakCheckR2012b(sp);
        }
      }

      /* Transition matrix update */
      for (j = 0; j < 1156; j++) {
        b_trans_mat_old[j] = trans_mat[j];
        trans_mat[j] = 0.0;
      }

      /* Select the top performing percentile of nodes from the paths */
      j = scored_paths->size[0];
      q = (int32_T)(rho_quantile_idx + 1U);
      if ((uint32_T)q > 255U) {
        q = 255;
      }

      if (!(q <= j)) {
        emlrtDynamicBoundsCheckR2012b(q, 1, j, &e_emlrtBCI, sp);
      }

      i2 = (int32_T)(rho_quantile_idx + 1U);
      if ((uint32_T)i2 > 255U) {
        i2 = 255;
      }

      j = high_scored_paths->size[0] * high_scored_paths->size[1];
      high_scored_paths->size[0] = i2;
      high_scored_paths->size[1] = 35;
      emxEnsureCapacity_real_T(sp, high_scored_paths, j, &g_emlrtRTEI);
      for (j = 0; j < 35; j++) {
        for (p = 0; p < i2; p++) {
          high_scored_paths->data[p + high_scored_paths->size[0] * j] =
            scored_paths->data[p + scored_paths->size[0] * j];
        }
      }

      /* Transition matrix counter */
      i2 = 0;
      while (i2 <= q - 1) {
        pEnd = 2;
        exitg2 = false;
        while ((!exitg2) && (pEnd - 2 <= 31)) {
          j = 1 + i2;
          if (!(j <= q)) {
            emlrtDynamicBoundsCheckR2012b(j, 1, q, &d_emlrtBCI, sp);
          }

          j = 1 + i2;
          if (!(j <= q)) {
            emlrtDynamicBoundsCheckR2012b(j, 1, q, &c_emlrtBCI, sp);
          }

          /* Account for node paths that don't visit all nodes due to */
          /* budget contraints */
          if ((scored_paths->data[i2 + scored_paths->size[0] * (pEnd - 1)] ==
               0.0) || (scored_paths->data[i2 + scored_paths->size[0] * pEnd] ==
                        0.0)) {
            exitg2 = true;
          } else {
            c = scored_paths->data[i2 + scored_paths->size[0] * (pEnd - 1)];
            if (c != (int32_T)muDoubleScalarFloor(c)) {
              emlrtIntegerCheckR2012b(c, &f_emlrtDCI, sp);
            }

            j = (int32_T)c;
            if (!((j >= 1) && (j <= 34))) {
              emlrtDynamicBoundsCheckR2012b(j, 1, 34, &t_emlrtBCI, sp);
            }

            c = scored_paths->data[i2 + scored_paths->size[0] * pEnd];
            if (c != (int32_T)muDoubleScalarFloor(c)) {
              emlrtIntegerCheckR2012b(c, &f_emlrtDCI, sp);
            }

            p = (int32_T)c;
            if (!((p >= 1) && (p <= 34))) {
              emlrtDynamicBoundsCheckR2012b(p, 1, 34, &t_emlrtBCI, sp);
            }

            c = scored_paths->data[i2 + scored_paths->size[0] * (pEnd - 1)];
            if (c != (int32_T)muDoubleScalarFloor(c)) {
              emlrtIntegerCheckR2012b(c, &g_emlrtDCI, sp);
            }

            qEnd = (int32_T)c;
            if (!((qEnd >= 1) && (qEnd <= 34))) {
              emlrtDynamicBoundsCheckR2012b(qEnd, 1, 34, &u_emlrtBCI, sp);
            }

            c = scored_paths->data[i2 + scored_paths->size[0] * pEnd];
            if (c != (int32_T)muDoubleScalarFloor(c)) {
              emlrtIntegerCheckR2012b(c, &g_emlrtDCI, sp);
            }

            kEnd = (int32_T)c;
            if (!((kEnd >= 1) && (kEnd <= 34))) {
              emlrtDynamicBoundsCheckR2012b(kEnd, 1, 34, &u_emlrtBCI, sp);
            }

            trans_mat[(qEnd + 34 * (kEnd - 1)) - 1] = trans_mat[(j + 34 * (p - 1))
              - 1] + 1.0;
            pEnd++;
            if (*emlrtBreakCheckR2012bFlagVar != 0) {
              emlrtBreakCheckR2012b(sp);
            }
          }
        }

        i2++;
        if (*emlrtBreakCheckR2012bFlagVar != 0) {
          emlrtBreakCheckR2012b(sp);
        }
      }

      /* Smoothly update the transition matrix */
      d_sum(trans_mat, trans_mat_old);
      memcpy(&b_trans_mat[0], &trans_mat[0], 1156U * sizeof(real_T));
      bsxfun(b_trans_mat, trans_mat_old, trans_mat);
      kEnd = 0;
      for (i = 0; i < 1156; i++) {
        overflow = muDoubleScalarIsNaN(trans_mat[i]);
        if (overflow) {
          kEnd++;
        }

        bv0[i] = overflow;
      }

      pEnd = 0;
      for (i = 0; i < 1156; i++) {
        if (bv0[i]) {
          b_tmp_data[pEnd] = (int16_T)(i + 1);
          pEnd++;
        }
      }

      for (j = 0; j < kEnd; j++) {
        trans_mat[b_tmp_data[j] - 1] = 0.0;
      }

      for (j = 0; j < 1156; j++) {
        trans_mat[j] = 0.5 * trans_mat[j] + 0.5 * b_trans_mat_old[j];
      }

      d_sum(trans_mat, trans_mat_old);
      memcpy(&b_trans_mat[0], &trans_mat[0], 1156U * sizeof(real_T));
      bsxfun(b_trans_mat, trans_mat_old, trans_mat);
      kEnd = 0;
      for (i = 0; i < 1156; i++) {
        overflow = muDoubleScalarIsNaN(trans_mat[i]);
        if (overflow) {
          kEnd++;
        }

        bv0[i] = overflow;
      }

      pEnd = 0;
      for (i = 0; i < 1156; i++) {
        if (bv0[i]) {
          c_tmp_data[pEnd] = (int16_T)(i + 1);
          pEnd++;
        }
      }

      for (j = 0; j < kEnd; j++) {
        trans_mat[c_tmp_data[j] - 1] = 0.0;
      }

      /* Optimisation performance metrics */
      i2 = gammas->size[1];
      j = gammas->size[0] * gammas->size[1];
      gammas->size[1] = i2 + 1;
      emxEnsureCapacity_real_T(sp, gammas, j, &e_emlrtRTEI);
      j = scored_paths->size[0];
      q = rho_quantile_idx;
      if (!(q <= j)) {
        emlrtDynamicBoundsCheckR2012b(q, 1, j, &o_emlrtBCI, sp);
      }

      gammas->data[i2] = scored_paths->data[q - 1];
      st.site = &b_emlrtRSI;
      b_st.site = &tb_emlrtRSI;
      na = scores->size[0];
      c_st.site = &ub_emlrtRSI;
      n = scores->size[0] + 1;
      i2 = scores->size[0];
      j = idx->size[0];
      idx->size[0] = i2;
      emxEnsureCapacity_int32_T(&c_st, idx, j, &h_emlrtRTEI);
      for (j = 0; j < i2; j++) {
        idx->data[j] = 0;
      }

      if (scores->size[0] != 0) {
        d_st.site = &ec_emlrtRSI;
        j = iwork->size[0];
        iwork->size[0] = i2;
        emxEnsureCapacity_int32_T(&d_st, iwork, j, &i_emlrtRTEI);
        e_st.site = &fc_emlrtRSI;
        overflow = ((!(1 > scores->size[0] - 1)) && (scores->size[0] - 1 >
          2147483645));
        if (overflow) {
          f_st.site = &w_emlrtRSI;
          check_forloop_overflow_error(&f_st);
        }

        for (k = 1; k <= n - 2; k += 2) {
          if ((scores->data[k - 1] <= scores->data[k]) || muDoubleScalarIsNaN
              (scores->data[k])) {
            idx->data[k - 1] = k;
            idx->data[k] = k + 1;
          } else {
            idx->data[k - 1] = k + 1;
            idx->data[k] = k;
          }
        }

        if ((scores->size[0] & 1) != 0) {
          idx->data[scores->size[0] - 1] = scores->size[0];
        }

        i = 2;
        while (i < n - 1) {
          i2 = i << 1;
          j = 1;
          for (pEnd = 1 + i; pEnd < n; pEnd = qEnd + i) {
            p = j;
            q = pEnd - 1;
            qEnd = j + i2;
            if (qEnd > n) {
              qEnd = n;
            }

            k = 0;
            kEnd = qEnd - j;
            while (k + 1 <= kEnd) {
              if ((scores->data[idx->data[p - 1] - 1] <= scores->data[idx->
                   data[q] - 1]) || muDoubleScalarIsNaN(scores->data[idx->data[q]
                   - 1])) {
                iwork->data[k] = idx->data[p - 1];
                p++;
                if (p == pEnd) {
                  while (q + 1 < qEnd) {
                    k++;
                    iwork->data[k] = idx->data[q];
                    q++;
                  }
                }
              } else {
                iwork->data[k] = idx->data[q];
                q++;
                if (q + 1 == qEnd) {
                  while (p < pEnd) {
                    k++;
                    iwork->data[k] = idx->data[p - 1];
                    p++;
                  }
                }
              }

              k++;
            }

            e_st.site = &gc_emlrtRSI;
            for (k = 0; k < kEnd; k++) {
              idx->data[(j + k) - 1] = iwork->data[k];
            }

            j = qEnd;
          }

          i = i2;
        }
      }

      scores_idx_0 = (uint32_T)scores->size[0];
      j = b->size[0];
      b->size[0] = (int32_T)scores_idx_0;
      emxEnsureCapacity_real_T1(&b_st, b, j, &j_emlrtRTEI);
      c_st.site = &vb_emlrtRSI;
      overflow = ((!(1 > scores->size[0])) && (scores->size[0] > 2147483646));
      if (overflow) {
        d_st.site = &w_emlrtRSI;
        check_forloop_overflow_error(&d_st);
      }

      for (k = 0; k < na; k++) {
        b->data[k] = scores->data[idx->data[k] - 1];
      }

      k = 0;
      while ((k + 1 <= na) && muDoubleScalarIsInf(b->data[k]) && (b->data[k] <
              0.0)) {
        k++;
      }

      q = k;
      k = scores->size[0];
      while ((k >= 1) && muDoubleScalarIsNaN(b->data[k - 1])) {
        k--;
      }

      kEnd = scores->size[0] - k;
      while ((k >= 1) && muDoubleScalarIsInf(b->data[k - 1]) && (b->data[k - 1] >
              0.0)) {
        k--;
      }

      qEnd = (scores->size[0] - k) - kEnd;
      p = 0;
      if (q > 0) {
        p = 1;
        c_st.site = &wb_emlrtRSI;
      }

      i2 = (q + k) - q;
      while (q + 1 <= i2) {
        x = b->data[q];
        pEnd = q;
        do {
          exitg3 = 0;
          q++;
          if (q + 1 > i2) {
            exitg3 = 1;
          } else {
            c_st.site = &xb_emlrtRSI;
            d_st.site = &hc_emlrtRSI;
            c = muDoubleScalarAbs(x / 2.0);
            if ((!muDoubleScalarIsInf(c)) && (!muDoubleScalarIsNaN(c))) {
              if (c <= 2.2250738585072014E-308) {
                c = 4.94065645841247E-324;
              } else {
                frexp(c, &exponent);
                c = ldexp(1.0, exponent - 53);
              }
            } else {
              c = rtNaN;
            }

            if ((muDoubleScalarAbs(x - b->data[q]) < c) || (muDoubleScalarIsInf
                 (b->data[q]) && muDoubleScalarIsInf(x) && ((b->data[q] > 0.0) ==
                  (x > 0.0)))) {
              overflow = true;
            } else {
              overflow = false;
            }

            if (!overflow) {
              exitg3 = 1;
            }
          }
        } while (exitg3 == 0);

        p++;
        b->data[p - 1] = x;
        c_st.site = &yb_emlrtRSI;
        if ((!(pEnd + 1 > q)) && (q > 2147483646)) {
          d_st.site = &w_emlrtRSI;
          check_forloop_overflow_error(&d_st);
        }
      }

      if (qEnd > 0) {
        p++;
        b->data[p - 1] = b->data[i2];
        c_st.site = &ac_emlrtRSI;
        if (qEnd > 2147483646) {
          d_st.site = &w_emlrtRSI;
          check_forloop_overflow_error(&d_st);
        }
      }

      q = i2 + qEnd;
      c_st.site = &bc_emlrtRSI;
      if ((!(1 > kEnd)) && (kEnd > 2147483646)) {
        d_st.site = &w_emlrtRSI;
        check_forloop_overflow_error(&d_st);
      }

      for (j = 1; j <= kEnd; j++) {
        p++;
        b->data[p - 1] = b->data[(q + j) - 1];
      }

      if (!(p <= scores->size[0])) {
        emlrtErrorWithMessageIdR2018a(&b_st, &v_emlrtRTEI,
          "Coder:builtins:AssertionFailed", "Coder:builtins:AssertionFailed", 0);
      }

      c_st.site = &cc_emlrtRSI;
      overflow = !(b->size[0] != 1);
      if (overflow) {
        overflow = false;
        if (1 > p) {
          i0 = 0;
        } else {
          i0 = p;
        }

        if (i0 != 1) {
          overflow = true;
        }

        if (overflow) {
          overflow = true;
        } else {
          overflow = false;
        }
      } else {
        overflow = false;
      }

      d_st.site = &ic_emlrtRSI;
      if (overflow) {
        emlrtErrorWithMessageIdR2018a(&d_st, &w_emlrtRTEI,
          "Coder:FE:PotentialVectorVector", "Coder:FE:PotentialVectorVector", 0);
      }

      c_st.site = &dc_emlrtRSI;
      if ((!(1 > p)) && (p > 2147483646)) {
        d_st.site = &w_emlrtRSI;
        check_forloop_overflow_error(&d_st);
      }

      /* Check for stopping condition, if the same optimisation performance */
      /* (gamma) occurred d times in a row then stop. */
      if (!(t < 5.0)) {
        j = gammas->size[1];
        q = gammas->size[1];
        if (!((q >= 1) && (q <= j))) {
          emlrtDynamicBoundsCheckR2012b(q, 1, j, &p_emlrtBCI, sp);
        }

        j = gammas->size[1];
        p = gammas->size[1] - 1;
        if (!((p >= 1) && (p <= j))) {
          emlrtDynamicBoundsCheckR2012b(p, 1, j, &q_emlrtBCI, sp);
        }

        if (gammas->data[q - 1] - gammas->data[p - 1] < 1.0E-12) {
          j = gammas->size[1];
          q = gammas->size[1];
          if (!((q >= 1) && (q <= j))) {
            emlrtDynamicBoundsCheckR2012b(q, 1, j, &r_emlrtBCI, sp);
          }

          j = gammas->size[1];
          p = gammas->size[1] - 1;
          if (!((p >= 1) && (p <= j))) {
            emlrtDynamicBoundsCheckR2012b(p, 1, j, &s_emlrtBCI, sp);
          }

          if (gammas->data[q - 1] >= gammas->data[p - 1]) {
            while_cond = 0;
          }
        }
      }

      t++;
      if (*emlrtBreakCheckR2012bFlagVar != 0) {
        emlrtBreakCheckR2012b(sp);
      }
    } else {
      exitg1 = 1;
    }
  } while (exitg1 == 0);

  emxFree_int32_T(sp, &iwork);
  emxFree_int32_T(sp, &idx);
  emxFree_real_T(sp, &b);
  emxFree_real_T(sp, &scored_paths);
  emxFree_real_T(sp, &scores);
  emxFree_real_T(sp, &path_list);
  emxFree_real_T(sp, &gammas);
  if (2 > high_scored_paths->size[1]) {
    j = 0;
    p = 0;
  } else {
    j = 1;
    q = high_scored_paths->size[1];
    p = high_scored_paths->size[1];
    if (!((p >= 1) && (p <= q))) {
      emlrtDynamicBoundsCheckR2012b(p, 1, q, &emlrtBCI, sp);
    }
  }

  q = high_scored_paths->size[0];
  if (!(1 <= q)) {
    emlrtDynamicBoundsCheckR2012b(1, 1, q, &b_emlrtBCI, sp);
  }

  ceTour_size[1] = p - j;
  i2 = p - j;
  for (q = 0; q < i2; q++) {
    ceTour_data[q] = high_scored_paths->data[high_scored_paths->size[0] * (j + q)];
  }

  i2 = (p - j) - 1;
  kEnd = 0;
  for (i = 0; i <= i2; i++) {
    if (high_scored_paths->data[high_scored_paths->size[0] * (j + i)] != 0.0) {
      kEnd++;
    }
  }

  emxFree_real_T(sp, &high_scored_paths);
  pEnd = 0;
  for (i = 0; i <= i2; i++) {
    if (ceTour_data[i] != 0.0) {
      if (!((i + 1 >= 1) && (i + 1 <= ceTour_size[1]))) {
        emlrtDynamicBoundsCheckR2012b(i + 1, 1, ceTour_size[1], &m_emlrtBCI, sp);
      }

      ceTour_data[pEnd] = ceTour_data[i];
      pEnd++;
    }
  }

  ceTour_size[0] = 1;
  ceTour_size[1] = kEnd;
  rwd_original_size[0] = kEnd;
  for (j = 0; j < kEnd; j++) {
    c = ceTour_data[j];
    if (c != (int32_T)muDoubleScalarFloor(c)) {
      emlrtIntegerCheckR2012b(c, &e_emlrtDCI, sp);
    }

    q = (int32_T)c;
    if (!((q >= 1) && (q <= 34))) {
      emlrtDynamicBoundsCheckR2012b(q, 1, 34, &n_emlrtBCI, sp);
    }

    rwd_original_data[j] = rwd_original[q - 1];
  }

  st.site = &emlrtRSI;
  *ceReward = e_sum(&st, rwd_original_data, rwd_original_size);
  emlrtHeapReferenceStackLeaveFcnR2012b(sp);
}

/* End of code generation (ce_algo_realworld.c) */
