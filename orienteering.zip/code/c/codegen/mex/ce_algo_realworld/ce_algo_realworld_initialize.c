/*
 * Student License - for use by students to meet course requirements and
 * perform academic research at degree granting institutions only.  Not
 * for government, commercial, or other organizational use.
 *
 * ce_algo_realworld_initialize.c
 *
 * Code generation for function 'ce_algo_realworld_initialize'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "ce_algo_realworld.h"
#include "ce_algo_realworld_initialize.h"
#include "_coder_ce_algo_realworld_mex.h"
#include "ce_algo_realworld_data.h"

/* Function Definitions */
void ce_algo_realworld_initialize(void)
{
  emlrtStack st = { NULL,              /* site */
    NULL,                              /* tls */
    NULL                               /* prev */
  };

  mexFunctionCreateRootTLS();
  emlrtBreakCheckR2012bFlagVar = emlrtGetBreakCheckFlagAddressR2012b();
  st.tls = emlrtRootTLSGlobal;
  emlrtClearAllocCountR2012b(&st, false, 0U, 0);
  emlrtEnterRtStackR2012b(&st);
  emlrtLicenseCheckR2012b(&st, "Statistics_Toolbox", 2);
  emlrtFirstTimeR2012b(emlrtRootTLSGlobal);
}

/* End of code generation (ce_algo_realworld_initialize.c) */
