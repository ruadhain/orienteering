/*
 * Student License - for use by students to meet course requirements and
 * perform academic research at degree granting institutions only.  Not
 * for government, commercial, or other organizational use.
 *
 * sum.c
 *
 * Code generation for function 'sum'
 *
 */

/* Include files */
#include <string.h>
#include "rt_nonfinite.h"
#include "ce_algo_realworld.h"
#include "sum.h"

/* Variable Definitions */
static emlrtRSInfo jc_emlrtRSI = { 9,  /* lineNo */
  "sum",                               /* fcnName */
  "/Applications/MATLAB_R2018a.app/toolbox/eml/lib/matlab/datafun/sum.m"/* pathName */
};

static emlrtRTEInfo cb_emlrtRTEI = { 22,/* lineNo */
  23,                                  /* colNo */
  "sumprod",                           /* fName */
  "/Applications/MATLAB_R2018a.app/toolbox/eml/lib/matlab/datafun/private/sumprod.m"/* pName */
};

/* Function Definitions */
real_T b_sum(const real_T x[34])
{
  real_T y;
  int32_T k;
  y = x[0];
  for (k = 0; k < 33; k++) {
    y += x[k + 1];
  }

  return y;
}

void c_sum(const real_T x[1156], real_T y[34])
{
  int32_T i;
  int32_T xpageoffset;
  int32_T k;
  for (i = 0; i < 34; i++) {
    xpageoffset = i * 34;
    y[i] = x[xpageoffset];
    for (k = 0; k < 33; k++) {
      y[i] += x[(xpageoffset + k) + 1];
    }
  }
}

void d_sum(const real_T x[1156], real_T y[34])
{
  int32_T k;
  int32_T xoffset;
  int32_T j;
  memcpy(&y[0], &x[0], 34U * sizeof(real_T));
  for (k = 0; k < 33; k++) {
    xoffset = (k + 1) * 34;
    for (j = 0; j < 34; j++) {
      y[j] += x[xoffset + j];
    }
  }
}

real_T e_sum(const emlrtStack *sp, const real_T x_data[], const int32_T x_size[1])
{
  real_T y;
  int32_T k;
  emlrtStack st;
  st.prev = sp;
  st.tls = sp->tls;
  st.site = &jc_emlrtRSI;
  if ((x_size[0] == 1) || (x_size[0] != 1)) {
  } else {
    emlrtErrorWithMessageIdR2018a(&st, &cb_emlrtRTEI,
      "Coder:toolbox:autoDimIncompatibility",
      "Coder:toolbox:autoDimIncompatibility", 0);
  }

  if (x_size[0] == 0) {
    y = 0.0;
  } else {
    y = x_data[0];
    for (k = 2; k <= x_size[0]; k++) {
      y += x_data[k - 1];
    }
  }

  return y;
}

real_T sum(const real_T x[34])
{
  real_T y;
  int32_T k;
  y = x[0];
  for (k = 0; k < 33; k++) {
    y += x[k + 1];
  }

  return y;
}

/* End of code generation (sum.c) */
