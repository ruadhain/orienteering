/*
 * Student License - for use by students to meet course requirements and
 * perform academic research at degree granting institutions only.  Not
 * for government, commercial, or other organizational use.
 *
 * diag.h
 *
 * Code generation for function 'diag'
 *
 */

#ifndef DIAG_H
#define DIAG_H

/* Include files */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "rtwtypes.h"
#include "ce_algo_realworld_types.h"

/* Function Declarations */
extern void b_diag(const real_T v[34], real_T d[1156]);
extern void diag(const real_T v[1156], real_T d[34]);

#endif

/* End of code generation (diag.h) */
