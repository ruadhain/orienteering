/*
 * Student License - for use by students to meet course requirements and
 * perform academic research at degree granting institutions only.  Not
 * for government, commercial, or other organizational use.
 *
 * sum.h
 *
 * Code generation for function 'sum'
 *
 */

#ifndef SUM_H
#define SUM_H

/* Include files */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "rtwtypes.h"
#include "ce_algo_realworld_types.h"

/* Function Declarations */
extern real_T b_sum(const real_T x[34]);
extern void c_sum(const real_T x[1156], real_T y[34]);
extern void d_sum(const real_T x[1156], real_T y[34]);
extern real_T e_sum(const emlrtStack *sp, const real_T x_data[], const int32_T
                    x_size[1]);
extern real_T sum(const real_T x[34]);

#endif

/* End of code generation (sum.h) */
