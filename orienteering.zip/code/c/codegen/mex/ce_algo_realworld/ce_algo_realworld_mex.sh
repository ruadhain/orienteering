MATLAB="/Applications/MATLAB_R2018a.app"
Arch=maci64
ENTRYPOINT=mexFunction
MAPFILE=$ENTRYPOINT'.map'
PREFDIR="/Users/my-account-name/Library/Application Support/MathWorks/MATLAB/R2018a"
OPTSFILE_NAME="./setEnv.sh"
. $OPTSFILE_NAME
COMPILER=$CC
. $OPTSFILE_NAME
echo "# Make settings for ce_algo_realworld" > ce_algo_realworld_mex.mki
echo "CC=$CC" >> ce_algo_realworld_mex.mki
echo "CFLAGS=$CFLAGS" >> ce_algo_realworld_mex.mki
echo "CLIBS=$CLIBS" >> ce_algo_realworld_mex.mki
echo "COPTIMFLAGS=$COPTIMFLAGS" >> ce_algo_realworld_mex.mki
echo "CDEBUGFLAGS=$CDEBUGFLAGS" >> ce_algo_realworld_mex.mki
echo "CXX=$CXX" >> ce_algo_realworld_mex.mki
echo "CXXFLAGS=$CXXFLAGS" >> ce_algo_realworld_mex.mki
echo "CXXLIBS=$CXXLIBS" >> ce_algo_realworld_mex.mki
echo "CXXOPTIMFLAGS=$CXXOPTIMFLAGS" >> ce_algo_realworld_mex.mki
echo "CXXDEBUGFLAGS=$CXXDEBUGFLAGS" >> ce_algo_realworld_mex.mki
echo "LDFLAGS=$LDFLAGS" >> ce_algo_realworld_mex.mki
echo "LDOPTIMFLAGS=$LDOPTIMFLAGS" >> ce_algo_realworld_mex.mki
echo "LDDEBUGFLAGS=$LDDEBUGFLAGS" >> ce_algo_realworld_mex.mki
echo "Arch=$Arch" >> ce_algo_realworld_mex.mki
echo "LD=$LD" >> ce_algo_realworld_mex.mki
echo OMPFLAGS= >> ce_algo_realworld_mex.mki
echo OMPLINKFLAGS= >> ce_algo_realworld_mex.mki
echo "EMC_COMPILER=clang" >> ce_algo_realworld_mex.mki
echo "EMC_CONFIG=optim" >> ce_algo_realworld_mex.mki
"/Applications/MATLAB_R2018a.app/bin/maci64/gmake" -j 1 -B -f ce_algo_realworld_mex.mk
