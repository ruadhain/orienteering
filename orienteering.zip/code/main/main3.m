%%  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all; close all;
load('satImageData_v5.mat');  % The chosen dataset is 'satImageData_v5.mat'
BGTVec = [200];
velocities = [0.1];
LKHAvgReward  = zeros(length(velocities),length(BGTVec));
benAvgReward  = zeros(length(velocities),length(BGTVec));
CEAvgReward  = zeros(length(velocities),length(BGTVec));
LKHTimer      = zeros(length(velocities),length(BGTVec));
benTimer      = zeros(length(velocities),length(BGTVec));
CETimer      = zeros(length(velocities),length(BGTVec));
LKHAvgLeftBgt = zeros(length(velocities),length(BGTVec));
benAvgLeftBgt = zeros(length(velocities),length(BGTVec));
CEAvgLeftBgt = zeros(length(velocities),length(BGTVec));

start_node = 1;

for bgtNo = 1:length(BGTVec)
    for velocityNo = 1:length(velocities) 
         % --LKH algorithm--
         tic;
         [tmpLKHAvgReward, tmpLKHAvgLeftBgt] = main3_sub_LKH(experimentalData, BGTVec(bgtNo), velocities(velocityNo), 1);
         LKHTimer(velocityNo, bgtNo) = LKHTimer(velocityNo, bgtNo) + toc;
         LKHAvgReward(velocityNo, bgtNo)  = tmpLKHAvgReward;
         LKHAvgLeftBgt(velocityNo, bgtNo) = tmpLKHAvgLeftBgt;
         % --benchmark algorithm--
         tic;
         [tmpBenAvgReward, tmpBenAvgLeftBgt] = main3_sub_bench(experimentalData, BGTVec(bgtNo), velocities(velocityNo), start_node);
         benTimer(velocityNo, bgtNo) = benTimer(velocityNo, bgtNo) + toc;
         benAvgReward(velocityNo, bgtNo)  = tmpBenAvgReward;
         benAvgLeftBgt(velocityNo, bgtNo) = tmpBenAvgLeftBgt;
         % --Cross Entropy Method--
         tic;
         [tmpCEAvgReward, tmpCEAvgLeftBgt, trans_mats] = main3_sub_ce(experimentalData, BGTVec(bgtNo), velocities(velocityNo), start_node, zeros(size(experimentalData,1),size(experimentalData,1),size(experimentalData,3)));
         CETimer(velocityNo, bgtNo) = CETimer(velocityNo, bgtNo) + toc;
         CEAvgReward(velocityNo, bgtNo)  = tmpCEAvgReward;
         CEAvgLeftBgt(velocityNo, bgtNo) = tmpCEAvgLeftBgt;
    end
end

disp(CEAvgReward);

RESULT_TABLE = [ 
                 BGTVec;
                 velocities;
                  benAvgReward;
                  LKHAvgReward;
                  CEAvgReward;
                  benTimer;
                  LKHTimer;
                  CETimer;
                  benAvgLeftBgt;
                  LKHAvgLeftBgt;
                  CEAvgLeftBgt;
               ];
           
save('tempRESULT.mat', 'RESULT_TABLE');
clear;
load('tempRESULT.mat', 'RESULT_TABLE');
