%%  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all; close all;
load('satImageData_v5.mat');  % The chosen dataset is 'satImageData_v5.mat'
BGTVec = [200];
velocities = [0.1];
LKHAvgReward  = zeros(length(velocities),length(BGTVec));
benAvgReward  = zeros(length(velocities),length(BGTVec));
CEAvgReward_control  = zeros(length(velocities),length(BGTVec));
CEAvgReward_exp  = zeros(length(velocities),length(BGTVec));
LKHTimer      = zeros(length(velocities),length(BGTVec));
benTimer      = zeros(length(velocities),length(BGTVec));
CETimer_control      = zeros(length(velocities),length(BGTVec));
CETimer_exp      = zeros(length(velocities),length(BGTVec));
LKHAvgLeftBgt = zeros(length(velocities),length(BGTVec));
benAvgLeftBgt = zeros(length(velocities),length(BGTVec));
CEAvgLeftBgt_control = zeros(length(velocities),length(BGTVec));
CEAvgLeftBgt_exp = zeros(length(velocities),length(BGTVec));

start_node = 1;

%node number, new x coord, new y coord
node_change = [13; 5.5; 2.4];

for i= 1:2
    for bgtNo = 1:length(BGTVec)
        for velocityNo = 1:length(velocities) 
             % --LKH algorithm--
             tic;
             [tmpLKHAvgReward, tmpLKHAvgLeftBgt] = main3_sub_LKH(experimentalData, BGTVec(bgtNo), velocities(velocityNo), 1);
             LKHTimer(velocityNo, bgtNo) = LKHTimer(velocityNo, bgtNo) + toc;
             LKHAvgReward(velocityNo, bgtNo)  = tmpLKHAvgReward;
             LKHAvgLeftBgt(velocityNo, bgtNo) = tmpLKHAvgLeftBgt;
             % --benchmark algorithm--
             tic;
             [tmpBenAvgReward, tmpBenAvgLeftBgt] = main3_sub_bench(experimentalData, BGTVec(bgtNo), velocities(velocityNo), start_node);
             benTimer(velocityNo, bgtNo) = benTimer(velocityNo, bgtNo) + toc;
             benAvgReward(velocityNo, bgtNo)  = tmpBenAvgReward;
             benAvgLeftBgt(velocityNo, bgtNo) = tmpBenAvgLeftBgt;
             % --Cross Entropy Method (control)--
             tic;
             [tmpCEAvgReward, tmpCEAvgLeftBgt, trans_mats] = main3_sub_ce(experimentalData, BGTVec(bgtNo), velocities(velocityNo), start_node, zeros(size(experimentalData,1),size(experimentalData,1),size(experimentalData,3)));
             CETimer_control(velocityNo, bgtNo) = CETimer_control(velocityNo, bgtNo) + toc;
             CEAvgReward_control(velocityNo, bgtNo)  = tmpCEAvgReward;
             CEAvgLeftBgt_control(velocityNo, bgtNo) = tmpCEAvgLeftBgt;
             if (i==1)
                %Change one node position
                for j = 1:10
                    experimentalData(node_change(1),1:2,j) = node_change(2:3);
                end
                %Get control transfer matrix
                control_trans_mats = trans_mats;
             elseif (i==2)
                 % --Cross Entropy Method (exp)--
                 tic;
                 [tmpCEAvgReward, tmpCEAvgLeftBgt, trans_mats] = main3_sub_ce(experimentalData, BGTVec(bgtNo), velocities(velocityNo), start_node, control_trans_mats);
                 CETimer_exp(velocityNo, bgtNo) = CETimer_exp(velocityNo, bgtNo) + toc;
                 CEAvgReward_exp(velocityNo, bgtNo)  = tmpCEAvgReward;
                 CEAvgLeftBgt_exp(velocityNo, bgtNo) = tmpCEAvgLeftBgt; 
             end
        end
    end

    RESULT_TABLE = [ 
                     BGTVec;
                     velocities;
                      benAvgReward;
                      LKHAvgReward;
                      CEAvgReward_control;
                      CEAvgReward_exp;
                      benTimer;
                      LKHTimer;
                      CETimer_control;
                      CETimer_exp;
                      benAvgLeftBgt;
                      LKHAvgLeftBgt;
                      CEAvgLeftBgt_control;
                      CEAvgLeftBgt_exp;
                   ];
    if (i==1)
        save('controlRESULT.mat', 'RESULT_TABLE');
    else
        save('experimentalRESULT.mat', 'RESULT_TABLE');
    end
end