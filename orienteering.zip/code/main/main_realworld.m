%%  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all; close all;
BGTVec = [999999999];
velocities = [1];
CEAvgReward  = zeros(length(velocities),length(BGTVec));
CETimer      = zeros(length(velocities),length(BGTVec));

load('CP.txt'); 
rwd = floor(CP(:,1)/10);
load('dists4.txt');
costs = dists4;

start_node = 1;

for bgtNo = 1:length(BGTVec)
    for velocityNo = 1:length(velocities) 
         tic;
         [ceTour, ceReward, trans_mat] = main_realworld_sub_ce(costs, rwd, BGTVec(bgtNo), velocities(velocityNo), start_node, zeros(size(costs)));
         CETimer(velocityNo, bgtNo) = CETimer(velocityNo, bgtNo) + toc;
         CEAvgReward(velocityNo, bgtNo)  = ceReward;
    end
end

disp('Optimal tour computed in ' + string(CETimer) + ' seconds')

RESULT_TABLE = [ 
                 BGTVec;
                 velocities;
                  CEAvgReward;
                  CETimer;
               ];

CP = CP(:,2:3);
tour = ceTour;
webmap;
wmcenter(CP(tour(1),1), CP(tour(1),2), 13);

for i = 1:length(tour)
   if (i == 1)
       wmmarker(CP(tour(i),1), CP(tour(i),2), 'FeatureName', string(i), 'Color', 'green')
   elseif (i == length(tour))
       lat = [CP(tour(i-1),1), CP(tour(i),1)];
       lon = [CP(tour(i-1),2), CP(tour(i),2)];
       wmline(lat, lon)
   else
       wmmarker(CP(tour(i),1), CP(tour(i),2), 'FeatureName', string(i), 'Color', 'red')
       lat = [CP(tour(i-1),1), CP(tour(i),1)];
       lon = [CP(tour(i-1),2), CP(tour(i),2)];
       wmline(lat, lon)
   end
end           